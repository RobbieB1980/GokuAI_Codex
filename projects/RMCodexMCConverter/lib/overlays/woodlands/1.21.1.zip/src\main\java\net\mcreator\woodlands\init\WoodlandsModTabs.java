package net.mcreator.woodlands.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@EventBusSubscriber
public class WoodlandsModTabs {
   public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "woodlands");
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> WOOD_LAND_TAB = REGISTRY.register(
      "wood_land_tab",
      () -> CreativeModeTab.builder()
         .title(Component.translatable("item_group.woodlands.wood_land_tab"))
         .icon(() -> new ItemStack(Blocks.OAK_PLANKS))
         .displayItems((parameters, tabData) -> {
            tabData.accept((ItemLike)WoodlandsModItems.WOOD_LAND.get());
            tabData.accept((ItemLike)WoodlandsModItems.WOODEN_HUMAN_SPAWN_EGG.get());
         })
         .build()
   );

   @SubscribeEvent
   public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
      if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
         tabData.accept((ItemLike)WoodlandsModItems.WOOD_LAND.get());
      } else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
         tabData.accept((ItemLike)WoodlandsModItems.WOODEN_HUMAN_SPAWN_EGG.get());
      }
   }
}
