package net.mcreator.woodlands.client.renderer;

import net.mcreator.woodlands.entity.WoodenHumanEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.ArmorModelSet;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;

public class WoodenHumanRenderer
   extends HumanoidMobRenderer<WoodenHumanEntity, HumanoidRenderState, HumanoidModel<HumanoidRenderState>> {
   private static final Identifier ENTITY_TEXTURE = Identifier.parse("woodlands:textures/entities/texture_wood_human.png");

   public WoodenHumanRenderer(Context context) {
      super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
      this.addLayer(
         new HumanoidArmorLayer<HumanoidRenderState, HumanoidModel<HumanoidRenderState>, HumanoidModel<HumanoidRenderState>>(
            this,
            ArmorModelSet.bake(
               ModelLayers.PLAYER_ARMOR,
               context.getModelSet(),
               part -> new HumanoidModel<HumanoidRenderState>(part)
            ),
            context.getEquipmentRenderer()
         )
      );
   }

   @Override
   public HumanoidRenderState createRenderState() {
      return new HumanoidRenderState();
   }

   @Override
   public Identifier getTextureLocation(HumanoidRenderState state) {
      return ENTITY_TEXTURE;
   }
}
