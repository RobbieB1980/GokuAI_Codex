package net.mcreator.woodlands.init;

import net.mcreator.woodlands.client.renderer.WoodenHumanRenderer;
import net.minecraft.world.entity.EntityType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers;

@EventBusSubscriber(Dist.CLIENT)
public class WoodlandsModEntityRenderers {
   @SubscribeEvent
   public static void registerEntityRenderers(RegisterRenderers event) {
      event.registerEntityRenderer((EntityType)WoodlandsModEntities.WOODEN_HUMAN.get(), WoodenHumanRenderer::new);
   }
}
