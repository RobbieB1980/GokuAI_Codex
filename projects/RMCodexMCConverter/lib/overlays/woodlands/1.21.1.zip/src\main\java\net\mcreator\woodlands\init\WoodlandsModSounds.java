package net.mcreator.woodlands.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class WoodlandsModSounds {
   public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, "woodlands");
   public static final DeferredHolder<SoundEvent, SoundEvent> WOODLANDMUSIC = REGISTRY.register(
      "woodlandmusic", () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("woodlands", "woodlandmusic"))
   );
}
