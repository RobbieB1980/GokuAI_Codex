package net.mcreator.woodlands;

import it.unimi.dsi.fastutil.ints.IntObjectImmutablePair;
import it.unimi.dsi.fastutil.ints.IntObjectPair;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.mcreator.woodlands.init.WoodlandsModBlocks;
import net.mcreator.woodlands.init.WoodlandsModEntities;
import net.mcreator.woodlands.init.WoodlandsModItems;
import net.mcreator.woodlands.init.WoodlandsModSounds;
import net.mcreator.woodlands.init.WoodlandsModTabs;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.server.TickTask;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.util.thread.SidedThreadGroups;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.ServerTickEvent.Post;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadHandler;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("woodlands")
public class WoodlandsMod {
   public static final Logger LOGGER = LogManager.getLogger(WoodlandsMod.class);
   public static final String MODID = "woodlands";
   private static boolean networkingRegistered = false;
   private static final Map<Type<?>, WoodlandsMod.NetworkMessage<?>> MESSAGES = new HashMap<>();
   private static final Queue<IntObjectPair<Runnable>> workToBeScheduled = new ConcurrentLinkedQueue<>();
   private static final PriorityQueue<TickTask> workQueue = new PriorityQueue<>(Comparator.comparingInt(TickTask::getTick));

   public WoodlandsMod(IEventBus modEventBus) {
      NeoForge.EVENT_BUS.register(this);
      modEventBus.addListener(this::registerNetworking);
      WoodlandsModSounds.REGISTRY.register(modEventBus);
      WoodlandsModBlocks.REGISTRY.register(modEventBus);
      WoodlandsModItems.REGISTRY.register(modEventBus);
      WoodlandsModEntities.REGISTRY.register(modEventBus);
      WoodlandsModTabs.REGISTRY.register(modEventBus);
   }

   public static <T extends CustomPacketPayload> void addNetworkMessage(
      Type<T> id, StreamCodec<? super RegistryFriendlyByteBuf, T> reader, IPayloadHandler<T> handler
   ) {
      if (networkingRegistered) {
         throw new IllegalStateException("Cannot register new network messages after networking has been registered");
      }

      MESSAGES.put(id, new WoodlandsMod.NetworkMessage(reader, handler));
   }

   private void registerNetworking(RegisterPayloadHandlersEvent event) {
      PayloadRegistrar registrar = event.registrar("woodlands");
      for (var entry : MESSAGES.entrySet()) {
         registerOne(registrar, entry.getKey(), entry.getValue());
      }
      networkingRegistered = true;
   }

   @SuppressWarnings("unchecked")
   private static <T extends CustomPacketPayload> void registerOne(
      PayloadRegistrar registrar, Type<?> id, WoodlandsMod.NetworkMessage<?> message
   ) {
      IPayloadHandler<T> handler = (IPayloadHandler<T>)message.handler();
      registrar.playBidirectional(
         (Type<T>)id,
         (StreamCodec<? super RegistryFriendlyByteBuf, T>)message.reader(),
         handler,
         handler
      );
   }

   public static void queueServerWork(int delay, Runnable action) {
      if (Thread.currentThread().getThreadGroup() == SidedThreadGroups.SERVER) {
         workToBeScheduled.add(new IntObjectImmutablePair(delay, action));
      }
   }

   @SubscribeEvent
   public void tick(Post event) {
      int currentTick = event.getServer().getTickCount();

      IntObjectPair<Runnable> work;
      while ((work = workToBeScheduled.poll()) != null) {
         workQueue.add(new TickTask(currentTick + work.leftInt(), (Runnable)work.right()));
      }

      while (!workQueue.isEmpty() && currentTick >= workQueue.peek().getTick()) {
         workQueue.poll().run();
      }
   }

   private record NetworkMessage<T extends CustomPacketPayload>(StreamCodec<? super RegistryFriendlyByteBuf, T> reader, IPayloadHandler<T> handler) {
   }
}
