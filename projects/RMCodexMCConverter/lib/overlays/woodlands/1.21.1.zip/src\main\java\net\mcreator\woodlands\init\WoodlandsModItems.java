package net.mcreator.woodlands.init;

import net.mcreator.woodlands.item.WoodLandItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.SpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Items;

public class WoodlandsModItems {
   public static final Items REGISTRY = DeferredRegister.createItems("woodlands");
   public static final DeferredItem<Item> WOOD_LAND = REGISTRY.registerItem("wood_land", WoodLandItem::new);
   public static final DeferredItem<Item> WOODEN_HUMAN_SPAWN_EGG = REGISTRY.registerItem("wooden_human_spawn_egg", p -> new SpawnEggItem(p.spawnEgg(WoodlandsModEntities.WOODEN_HUMAN.get()))
   );
}
