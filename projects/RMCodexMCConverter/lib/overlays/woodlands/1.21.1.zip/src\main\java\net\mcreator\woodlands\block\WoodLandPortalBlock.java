package net.mcreator.woodlands.block;

import com.mojang.logging.LogUtils;
import java.util.Optional;
import org.jetbrains.annotations.Nullable;
import net.mcreator.woodlands.world.teleporter.WoodLandPortalShape;
import net.mcreator.woodlands.world.teleporter.WoodLandTeleporter;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.BlockUtil;
import net.minecraft.util.BlockUtil.FoundRectangle;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.NetherPortalBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Portal.Transition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.level.portal.TeleportTransition.PostTeleportTransition;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.slf4j.Logger;

public class WoodLandPortalBlock extends NetherPortalBlock {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static void portalSpawn(Level world, BlockPos pos) {
      Optional<WoodLandPortalShape> optional = WoodLandPortalShape.findEmptyPortalShape(world, pos, Axis.X);
      if (optional.isPresent()) {
         optional.get().createPortalBlocks(world);
      }
   }

   public WoodLandPortalBlock(net.minecraft.world.level.block.state.BlockBehaviour.Properties properties) {
      super(
         properties
            .noCollision()
            .randomTicks()
            .pushReaction(PushReaction.BLOCK)
            .strength(-1.0F)
            .sound(SoundType.GLASS)
            .lightLevel(state -> 3)
            .noLootTable()
      );
   }

   private WoodLandTeleporter getTeleporter(ServerLevel level) {
      return new WoodLandTeleporter(level);
   }

   @Override
   protected BlockState updateShape(
      BlockState state, LevelReader level, ScheduledTickAccess ticks, BlockPos pos,
      Direction directionToNeighbour, BlockPos neighbourPos, BlockState neighbourState, RandomSource random
   ) {
      Axis updateAxis = directionToNeighbour.getAxis();
      Axis axis = state.getValue(AXIS);
      boolean wrongAxis = axis != updateAxis && updateAxis.isHorizontal();
      return !wrongAxis && !neighbourState.is(this) && !new WoodLandPortalShape(level, pos, axis).isComplete()
         ? Blocks.AIR.defaultBlockState()
         : super.updateShape(state, level, ticks, pos, directionToNeighbour, neighbourPos, neighbourState, random);
   }

   @Nullable
   public TeleportTransition getPortalDestination(ServerLevel p_350444_, Entity p_350334_, BlockPos p_350764_) {
      ResourceKey<Level> woodLand = ResourceKey.create(Registries.DIMENSION, Identifier.parse("woodlands:wood_land"));
      ResourceKey<Level> destination = p_350444_.dimension().equals(woodLand) ? Level.OVERWORLD : woodLand;
      ServerLevel serverlevel = p_350444_.getServer().getLevel(destination);
      if (serverlevel == null) {
         return null;
      }

      boolean flag = serverlevel.dimension().equals(woodLand);
      WorldBorder worldborder = serverlevel.getWorldBorder();
      double d0 = DimensionType.getTeleportationScale(p_350444_.dimensionType(), serverlevel.dimensionType());
      BlockPos blockpos = worldborder.clampToBounds(p_350334_.getX() * d0, p_350334_.getY(), p_350334_.getZ() * d0);
      return this.getExitPortal(serverlevel, p_350334_, p_350764_, blockpos, flag, worldborder);
   }

   @Nullable
   private TeleportTransition getExitPortal(
      ServerLevel p_350564_, Entity p_350493_, BlockPos p_350379_, BlockPos p_350747_, boolean p_350326_, WorldBorder p_350718_
   ) {
      Optional<BlockPos> optional = this.getTeleporter(p_350564_).findClosestPortalPosition(p_350747_, p_350326_, p_350718_);
      FoundRectangle blockutil$foundrectangle;
      PostTeleportTransition dimensiontransition$postdimensiontransition;
      if (optional.isPresent()) {
         BlockPos blockpos = optional.get();
         blockutil$foundrectangle = new FoundRectangle(blockpos, 2, 3);
         dimensiontransition$postdimensiontransition = TeleportTransition.PLAY_PORTAL_SOUND.then(TeleportTransition.PLACE_PORTAL_TICKET);
      } else {
         Axis direction$axis = p_350493_.level().getBlockState(p_350379_).getOptionalValue(AXIS).orElse(Axis.X);
         Optional<FoundRectangle> optional1 = this.getTeleporter(p_350564_).createPortal(p_350747_, direction$axis);
         if (optional1.isEmpty()) {
            LOGGER.error("Unable to create a portal, likely target out of worldborder");
            return null;
         }

         blockutil$foundrectangle = optional1.get();
         dimensiontransition$postdimensiontransition = TeleportTransition.PLAY_PORTAL_SOUND.then(TeleportTransition.PLACE_PORTAL_TICKET);
      }

      return getDimensionTransitionFromExit(p_350493_, p_350379_, blockutil$foundrectangle, p_350564_, dimensiontransition$postdimensiontransition);
   }

   private static TeleportTransition getDimensionTransitionFromExit(
      Entity entity, BlockPos entry, FoundRectangle exit, ServerLevel newLevel, PostTeleportTransition post
   ) {
      BlockState state = entity.level().getBlockState(entry);
      Axis axis;
      Vec3 offset;
      if (state.hasProperty(BlockStateProperties.HORIZONTAL_AXIS)) {
         axis = state.getValue(BlockStateProperties.HORIZONTAL_AXIS);
         FoundRectangle area = BlockUtil.getLargestRectangleAround(
            entry, axis, 21, Axis.Y, 21, pos -> entity.level().getBlockState(pos) == state
         );
         offset = entity.getRelativePortalPosition(axis, area);
      } else {
         axis = Axis.X;
         offset = new Vec3(0.5, 0.0, 0.0);
      }
      return createDimensionTransition(newLevel, exit, axis, offset, entity, post);
   }

   private static TeleportTransition createDimensionTransition(
      ServerLevel newLevel, FoundRectangle rectangle, Axis portalAxis, Vec3 offset,
      Entity entity, PostTeleportTransition post
   ) {
      BlockPos bottomLeft = rectangle.minCorner;
      BlockState state = newLevel.getBlockState(bottomLeft);
      Axis axis = state.getOptionalValue(BlockStateProperties.HORIZONTAL_AXIS).orElse(Axis.X);
      double width = rectangle.axis1Size;
      double height = rectangle.axis2Size;
      EntityDimensions dimensions = entity.getDimensions(entity.getPose());
      int outputRotation = portalAxis == axis ? 0 : 90;
      double right = dimensions.width() / 2.0 + (width - dimensions.width()) * offset.x();
      double up = (height - dimensions.height()) * offset.y();
      double forward = 0.5 + offset.z();
      boolean xAligned = axis == Axis.X;
      Vec3 target = new Vec3(
         bottomLeft.getX() + (xAligned ? right : forward),
         bottomLeft.getY() + up,
         bottomLeft.getZ() + (xAligned ? forward : right)
      );
      Vec3 safe = WoodLandPortalShape.findCollisionFreePosition(target, newLevel, entity, dimensions);
      return new TeleportTransition(
         newLevel, safe, Vec3.ZERO, outputRotation, 0.0F,
         Relative.union(Relative.DELTA, Relative.ROTATION), post
      );
   }

   public int getPortalTransitionTime(ServerLevel world, Entity entity) {
      return 0;
   }

   public Transition getLocalTransition() {
      return Transition.NONE;
   }

   public void randomTick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
   }

   @OnlyIn(Dist.CLIENT)
   public void animateTick(BlockState state, Level world, BlockPos pos, RandomSource random) {
      for (int i = 0; i < 4; i++) {
         double px = pos.getX() + random.nextFloat();
         double py = pos.getY() + random.nextFloat();
         double pz = pos.getZ() + random.nextFloat();
         double vx = (random.nextFloat() - 0.5) / 2.0;
         double vy = (random.nextFloat() - 0.5) / 2.0;
         double vz = (random.nextFloat() - 0.5) / 2.0;
         int j = random.nextInt(4) - 1;
         if (world.getBlockState(pos.west()).getBlock() != this && world.getBlockState(pos.east()).getBlock() != this) {
            px = pos.getX() + 0.5 + 0.25 * j;
            vx = random.nextFloat() * 2.0F * j;
         } else {
            pz = pos.getZ() + 0.5 + 0.25 * j;
            vz = random.nextFloat() * 2.0F * j;
         }

         world.addParticle(ParticleTypes.ASH, px, py, pz, vx, vy, vz);
      }

      if (random.nextInt(110) == 0) {
         world.playSound(
            null,
            pos.getX() + 0.5,
            pos.getY() + 0.5,
            pos.getZ() + 0.5,
            BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("block.portal.ambient")),
            SoundSource.BLOCKS,
            0.5F,
            random.nextFloat() * 0.4F + 0.8F
         );
      }
   }
}