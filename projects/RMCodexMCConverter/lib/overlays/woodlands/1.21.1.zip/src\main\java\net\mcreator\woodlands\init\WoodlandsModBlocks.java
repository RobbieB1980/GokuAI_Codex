package net.mcreator.woodlands.init;

import net.mcreator.woodlands.block.WoodLandPortalBlock;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Blocks;

public class WoodlandsModBlocks {
   public static final Blocks REGISTRY = DeferredRegister.createBlocks("woodlands");
   public static final DeferredBlock<Block> WOOD_LAND_PORTAL = REGISTRY.registerBlock("wood_land_portal", WoodLandPortalBlock::new);
}
