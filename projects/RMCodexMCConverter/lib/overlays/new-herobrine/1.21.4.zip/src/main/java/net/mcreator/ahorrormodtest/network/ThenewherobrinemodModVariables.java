package net.mcreator.ahorrormodtest.network;

import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerChangedDimensionEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries.Keys;

@EventBusSubscriber
public class ThenewherobrinemodModVariables {
   public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES = DeferredRegister.create(Keys.ATTACHMENT_TYPES, "thenewherobrinemod");

   @SubscribeEvent
   public static void init(FMLCommonSetupEvent event) {
      ThenewherobrinemodMod.addNetworkMessage(
         ThenewherobrinemodModVariables.SavedDataSyncMessage.TYPE,
         ThenewherobrinemodModVariables.SavedDataSyncMessage.STREAM_CODEC,
         ThenewherobrinemodModVariables.SavedDataSyncMessage::handleData
      );
   }

   @EventBusSubscriber
   public static class EventBusVariableHandlers {
      @SubscribeEvent
      public static void onPlayerLoggedIn(PlayerLoggedInEvent event) {
         if (event.getEntity() instanceof ServerPlayer player) {
            SavedData mapdata = ThenewherobrinemodModVariables.MapVariables.get(event.getEntity().level());
            SavedData worlddata = ThenewherobrinemodModVariables.WorldVariables.get(event.getEntity().level());
            if (mapdata != null) {
               PacketDistributor.sendToPlayer(player, new ThenewherobrinemodModVariables.SavedDataSyncMessage(0, mapdata), new CustomPacketPayload[0]);
            }

            if (worlddata != null) {
               PacketDistributor.sendToPlayer(player, new ThenewherobrinemodModVariables.SavedDataSyncMessage(1, worlddata), new CustomPacketPayload[0]);
            }
         }
      }

      @SubscribeEvent
      public static void onPlayerChangedDimension(PlayerChangedDimensionEvent event) {
         if (event.getEntity() instanceof ServerPlayer player) {
            SavedData worlddata = ThenewherobrinemodModVariables.WorldVariables.get(event.getEntity().level());
            if (worlddata != null) {
               PacketDistributor.sendToPlayer(player, new ThenewherobrinemodModVariables.SavedDataSyncMessage(1, worlddata), new CustomPacketPayload[0]);
            }
         }
      }
   }

   public static class MapVariables extends SavedData {
      public static final String DATA_NAME = "thenewherobrinemod_mapvars";
      public static final com.mojang.serialization.Codec<ThenewherobrinemodModVariables.MapVariables> CODEC = CompoundTag.CODEC.xmap(tag -> {
         ThenewherobrinemodModVariables.MapVariables instance = new ThenewherobrinemodModVariables.MapVariables();
         instance.read(tag, null);
         return instance;
      }, instance -> instance.save(new CompoundTag(), null));
      public static final SavedDataType<ThenewherobrinemodModVariables.MapVariables> TYPE = new SavedDataType<>(
         Identifier.fromNamespaceAndPath("thenewherobrinemod", "mapvars"),
         ThenewherobrinemodModVariables.MapVariables::new,
         CODEC
      );
      static ThenewherobrinemodModVariables.MapVariables clientSide = new ThenewherobrinemodModVariables.MapVariables();

      public void read(CompoundTag nbt, Provider lookupProvider) {
      }

      public CompoundTag save(CompoundTag nbt, Provider lookupProvider) {
         return nbt;
      }

      public void syncData(LevelAccessor world) {
         this.setDirty();
         if (world instanceof Level && !world.isClientSide()) {
            PacketDistributor.sendToAllPlayers(new ThenewherobrinemodModVariables.SavedDataSyncMessage(0, this), new CustomPacketPayload[0]);
         }
      }

      public static ThenewherobrinemodModVariables.MapVariables get(LevelAccessor world) {
         return world instanceof ServerLevelAccessor serverLevelAcc
            ? serverLevelAcc.getLevel()
               .getServer()
               .getLevel(Level.OVERWORLD)
               .getDataStorage()
               .computeIfAbsent(TYPE)
            : clientSide;
      }
   }

   public record SavedDataSyncMessage(int dataType, SavedData data) implements CustomPacketPayload {
      public static final Type<ThenewherobrinemodModVariables.SavedDataSyncMessage> TYPE = new Type(
         Identifier.fromNamespaceAndPath("thenewherobrinemod", "saved_data_sync")
      );
      public static final StreamCodec<RegistryFriendlyByteBuf, ThenewherobrinemodModVariables.SavedDataSyncMessage> STREAM_CODEC = StreamCodec.of(
         (buffer, message) -> {
            buffer.writeInt(message.dataType);
            if (message.data != null) {
               CompoundTag tag = message.data instanceof ThenewherobrinemodModVariables.WorldVariables wv
                  ? wv.save(new CompoundTag(), buffer.registryAccess())
                  : ((ThenewherobrinemodModVariables.MapVariables)message.data).save(new CompoundTag(), buffer.registryAccess());
               buffer.writeNbt(tag);
            }
         }, buffer -> {
            int dataType = buffer.readInt();
            CompoundTag nbt = buffer.readNbt();
            SavedData data = null;
            if (nbt != null) {
               data = (SavedData)(dataType == 0 ? new ThenewherobrinemodModVariables.MapVariables() : new ThenewherobrinemodModVariables.WorldVariables());
               if (data instanceof ThenewherobrinemodModVariables.MapVariables mapVariables) {
                  mapVariables.read(nbt, buffer.registryAccess());
               } else if (data instanceof ThenewherobrinemodModVariables.WorldVariables worldVariables) {
                  worldVariables.read(nbt, buffer.registryAccess());
               }
            }

            return new ThenewherobrinemodModVariables.SavedDataSyncMessage(dataType, data);
         }
      );

      public Type<ThenewherobrinemodModVariables.SavedDataSyncMessage> type() {
         return TYPE;
      }

      public static void handleData(ThenewherobrinemodModVariables.SavedDataSyncMessage message, IPayloadContext context) {
         if (context.flow() == PacketFlow.CLIENTBOUND && message.data != null) {
            context.enqueueWork(
                  () -> {
                     if (message.dataType == 0) {
                        ThenewherobrinemodModVariables.MapVariables.clientSide.read(
                           ((ThenewherobrinemodModVariables.MapVariables)message.data).save(new CompoundTag(), context.player().registryAccess()),
                           context.player().registryAccess()
                        );
                     } else {
                        ThenewherobrinemodModVariables.WorldVariables.clientSide.read(
                           ((ThenewherobrinemodModVariables.WorldVariables)message.data).save(new CompoundTag(), context.player().registryAccess()),
                           context.player().registryAccess()
                        );
                     }
                  }
               )
               .exceptionally(e -> {
                  context.connection().disconnect(Component.literal(e.getMessage()));
                  return null;
               });
         }
      }
   }

   public static class WorldVariables extends SavedData {
      public static final String DATA_NAME = "thenewherobrinemod_worldvars";
      public static final com.mojang.serialization.Codec<ThenewherobrinemodModVariables.WorldVariables> CODEC = CompoundTag.CODEC.xmap(tag -> {
         ThenewherobrinemodModVariables.WorldVariables instance = new ThenewherobrinemodModVariables.WorldVariables();
         instance.read(tag, null);
         return instance;
      }, instance -> instance.save(new CompoundTag(), null));
      public static final SavedDataType<ThenewherobrinemodModVariables.WorldVariables> TYPE = new SavedDataType<>(
         Identifier.fromNamespaceAndPath("thenewherobrinemod", "worldvars"),
         ThenewherobrinemodModVariables.WorldVariables::new,
         CODEC
      );
      public double Far_Herobrine_Sword_Type = 1.0;
      public double Herobrine_Spawn_Timer = 0.0;
      public double Herobrine_Spawn_Timer_Time = 0.0;
      public double Herobrine_Spawn_Type = 0.0;
      public double Herobrine_Spawn_Speed = 1.0;
      public double First_Time = 1.0;
      public double Herobrine_Anger = 0.0;
      public double Herobrine_Anger_Action_Type = 0.0;
      public double Herobrine_Not_Spawned_Times = 0.0;
      public double WasJumpscare = 0.0;
      public double CONFIG_JumpscaresEnabled = 1.0;
      public double CONFIG_FarHerobrineEnabled = 1.0;
      public double CONFIG_CrucifixSpawn = 1.0;
      public double CONFIG_HerobrineBehindEnabled = 1.0;
      public Direction HerobrineBehindOrientation = Direction.NORTH;
      public double Events_Not_Spawned_Times = 0.0;
      public double CONFIG_HerobrineAttackEnabled = 1.0;
      public double FarHerobrineNotSpawnedTimes = 0.0;
      public double HerobrineAngerDisplayConfirmed = 0.0;
      public double TEMP_CurrentWorldHourTemp = 0.0;
      static ThenewherobrinemodModVariables.WorldVariables clientSide = new ThenewherobrinemodModVariables.WorldVariables();

      public void read(CompoundTag nbt, Provider lookupProvider) {
         this.Far_Herobrine_Sword_Type = nbt.getDoubleOr("Far_Herobrine_Sword_Type", 0.0);
         this.Herobrine_Spawn_Timer = nbt.getDoubleOr("Herobrine_Spawn_Timer", 0.0);
         this.Herobrine_Spawn_Timer_Time = nbt.getDoubleOr("Herobrine_Spawn_Timer_Time", 0.0);
         this.Herobrine_Spawn_Type = nbt.getDoubleOr("Herobrine_Spawn_Type", 0.0);
         this.Herobrine_Spawn_Speed = nbt.getDoubleOr("Herobrine_Spawn_Speed", 0.0);
         this.First_Time = nbt.getDoubleOr("First_Time", 0.0);
         this.Herobrine_Anger = nbt.getDoubleOr("Herobrine_Anger", 0.0);
         this.Herobrine_Anger_Action_Type = nbt.getDoubleOr("Herobrine_Anger_Action_Type", 0.0);
         this.Herobrine_Not_Spawned_Times = nbt.getDoubleOr("Herobrine_Not_Spawned_Times", 0.0);
         this.WasJumpscare = nbt.getDoubleOr("WasJumpscare", 0.0);
         this.CONFIG_JumpscaresEnabled = nbt.getDoubleOr("CONFIG_JumpscaresEnabled", 0.0);
         this.CONFIG_FarHerobrineEnabled = nbt.getDoubleOr("CONFIG_FarHerobrineEnabled", 0.0);
         this.CONFIG_CrucifixSpawn = nbt.getDoubleOr("CONFIG_CrucifixSpawn", 0.0);
         this.CONFIG_HerobrineBehindEnabled = nbt.getDoubleOr("CONFIG_HerobrineBehindEnabled", 0.0);
         this.HerobrineBehindOrientation = Direction.from3DDataValue(nbt.getIntOr("HerobrineBehindOrientation", 0));
         this.Events_Not_Spawned_Times = nbt.getDoubleOr("Events_Not_Spawned_Times", 0.0);
         this.CONFIG_HerobrineAttackEnabled = nbt.getDoubleOr("CONFIG_HerobrineAttackEnabled", 0.0);
         this.FarHerobrineNotSpawnedTimes = nbt.getDoubleOr("FarHerobrineNotSpawnedTimes", 0.0);
         this.HerobrineAngerDisplayConfirmed = nbt.getDoubleOr("HerobrineAngerDisplayConfirmed", 0.0);
         this.TEMP_CurrentWorldHourTemp = nbt.getDoubleOr("TEMP_CurrentWorldHourTemp", 0.0);
      }

      public CompoundTag save(CompoundTag nbt, Provider lookupProvider) {
         nbt.putDouble("Far_Herobrine_Sword_Type", this.Far_Herobrine_Sword_Type);
         nbt.putDouble("Herobrine_Spawn_Timer", this.Herobrine_Spawn_Timer);
         nbt.putDouble("Herobrine_Spawn_Timer_Time", this.Herobrine_Spawn_Timer_Time);
         nbt.putDouble("Herobrine_Spawn_Type", this.Herobrine_Spawn_Type);
         nbt.putDouble("Herobrine_Spawn_Speed", this.Herobrine_Spawn_Speed);
         nbt.putDouble("First_Time", this.First_Time);
         nbt.putDouble("Herobrine_Anger", this.Herobrine_Anger);
         nbt.putDouble("Herobrine_Anger_Action_Type", this.Herobrine_Anger_Action_Type);
         nbt.putDouble("Herobrine_Not_Spawned_Times", this.Herobrine_Not_Spawned_Times);
         nbt.putDouble("WasJumpscare", this.WasJumpscare);
         nbt.putDouble("CONFIG_JumpscaresEnabled", this.CONFIG_JumpscaresEnabled);
         nbt.putDouble("CONFIG_FarHerobrineEnabled", this.CONFIG_FarHerobrineEnabled);
         nbt.putDouble("CONFIG_CrucifixSpawn", this.CONFIG_CrucifixSpawn);
         nbt.putDouble("CONFIG_HerobrineBehindEnabled", this.CONFIG_HerobrineBehindEnabled);
         nbt.putInt("HerobrineBehindOrientation", this.HerobrineBehindOrientation.get3DDataValue());
         nbt.putDouble("Events_Not_Spawned_Times", this.Events_Not_Spawned_Times);
         nbt.putDouble("CONFIG_HerobrineAttackEnabled", this.CONFIG_HerobrineAttackEnabled);
         nbt.putDouble("FarHerobrineNotSpawnedTimes", this.FarHerobrineNotSpawnedTimes);
         nbt.putDouble("HerobrineAngerDisplayConfirmed", this.HerobrineAngerDisplayConfirmed);
         nbt.putDouble("TEMP_CurrentWorldHourTemp", this.TEMP_CurrentWorldHourTemp);
         return nbt;
      }

      public void syncData(LevelAccessor world) {
         this.setDirty();
         if (world instanceof ServerLevel level) {
            PacketDistributor.sendToPlayersInDimension(level, new ThenewherobrinemodModVariables.SavedDataSyncMessage(1, this), new CustomPacketPayload[0]);
         }
      }

      public static ThenewherobrinemodModVariables.WorldVariables get(LevelAccessor world) {
         return world instanceof ServerLevel level
            ? level.getDataStorage().computeIfAbsent(TYPE)
            : clientSide;
      }
   }
}
