package net.mcreator.ahorrormodtest.init;

import net.mcreator.ahorrormodtest.client.renderer.CowTestPlayerRenderer;
import net.mcreator.ahorrormodtest.client.renderer.FarherobrineRenderer;
import net.mcreator.ahorrormodtest.client.renderer.HerobrineAttaquerRenderer;
import net.mcreator.ahorrormodtest.client.renderer.HerobrineBehindRenderer;
import net.mcreator.ahorrormodtest.client.renderer.JumpscareHerobrineRenderer;
import net.mcreator.ahorrormodtest.client.renderer.PigPlayerTestRenderer;
import net.mcreator.ahorrormodtest.client.renderer.PossessedCowRenderer;
import net.mcreator.ahorrormodtest.client.renderer.PossessedPigRenderer;
import net.minecraft.world.entity.EntityType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers;

@EventBusSubscriber(Dist.CLIENT)
public class ThenewherobrinemodModEntityRenderers {
   @SubscribeEvent
   public static void registerEntityRenderers(RegisterRenderers event) {
      event.registerEntityRenderer((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get(), FarherobrineRenderer::new);
      event.registerEntityRenderer((EntityType)ThenewherobrinemodModEntities.HEROBRINE_ATTAQUER.get(), HerobrineAttaquerRenderer::new);
      event.registerEntityRenderer((EntityType)ThenewherobrinemodModEntities.POSSESSED_COW.get(), PossessedCowRenderer::new);
      event.registerEntityRenderer((EntityType)ThenewherobrinemodModEntities.JUMPSCARE_HEROBRINE.get(), JumpscareHerobrineRenderer::new);
      event.registerEntityRenderer((EntityType)ThenewherobrinemodModEntities.COW_TEST_PLAYER.get(), CowTestPlayerRenderer::new);
      event.registerEntityRenderer((EntityType)ThenewherobrinemodModEntities.POSSESSED_PIG.get(), PossessedPigRenderer::new);
      event.registerEntityRenderer((EntityType)ThenewherobrinemodModEntities.PIG_PLAYER_TEST.get(), PigPlayerTestRenderer::new);
      event.registerEntityRenderer((EntityType)ThenewherobrinemodModEntities.HEROBRINE_BEHIND.get(), HerobrineBehindRenderer::new);
   }
}
