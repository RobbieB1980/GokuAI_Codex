package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModEntities;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap.Types;

public class ACTIONEvent1Procedure {
   public static void execute(LevelAccessor world, double x, double z) {
      if (world instanceof ServerLevel _level) {
         Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.COW_TEST_PLAYER.get())
            .spawn(
               _level,
               BlockPos.containing(x, world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)x, (int)(z - 20.0)) + 1, z - 20.0),
               EntitySpawnReason.MOB_SUMMONED
            );
         if (entityToSpawn != null) {
            entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
         }
      }

      ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
      ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
   }
}
