package net.mcreator.ahorrormodtest.init;

import java.util.function.Function;
import net.mcreator.ahorrormodtest.block.HerobrineOreBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Blocks;

public class ThenewherobrinemodModBlocks {
   public static final Blocks REGISTRY = DeferredRegister.createBlocks("thenewherobrinemod");
   public static final DeferredBlock<Block> HEROBRINE_ORE = register("herobrine_ore", HerobrineOreBlock::new);

   private static <B extends Block> DeferredBlock<B> register(String name, Function<Properties, ? extends B> supplier) {
      return REGISTRY.registerBlock(name, supplier, () -> Properties.of());
   }
}
