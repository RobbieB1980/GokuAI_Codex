package net.mcreator.ahorrormodtest.client.screens;

import net.mcreator.ahorrormodtest.procedures.ShowMainMenuHeadProcedure;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent.Render.Post;

@EventBusSubscriber(Dist.CLIENT)
public class EasterEggHerobrineOnMainMenuOverlay {
   @SubscribeEvent(priority = EventPriority.LOWEST)
   public static void eventHandler(Post event) {
      if (event.getScreen() instanceof TitleScreen) {
         int w = event.getGuiGraphics().guiWidth();
         int h = event.getGuiGraphics().guiHeight();
         Level world = null;
         double x = 0.0;
         double y = 0.0;
         double z = 0.0;
         Player entity = Minecraft.getInstance().player;
         if (entity != null) {
            world = entity.level();
            x = entity.getX();
            y = entity.getY();
            z = entity.getZ();
         }
         if (ShowMainMenuHeadProcedure.execute()) {
            event.getGuiGraphics()
               .blit(
                  net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, Identifier.parse("thenewherobrinemod:textures/screens/herobrinehead.png"), w - 11, 3, 0.0F, 0.0F, 8, 8, 8, 8
               );
         }
      }
   }
}
