package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.Vec3;

public class EVENTSHerobrineAttackNormalSpawnProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (world instanceof ServerLevel _level) {
            Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.HEROBRINE_ATTAQUER.get())
               .spawn(
                  _level,
                  BlockPos.containing(x, world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)x, (int)(z + 1.0)), z + 1.0),
                  EntitySpawnReason.MOB_SUMMONED
               );
            if (entityToSpawn != null) {
               entityToSpawn.setYRot(entity.getYRot() - 180.0F);
               entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
               entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
               entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
            }
         }

         if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && world instanceof Level _level) {
            if (!_level.isClientSide()) {
               _level.playSound(
                  null,
                  BlockPos.containing(x, y, z),
                  (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:jumpscare_sound_1")),
                  SoundSource.NEUTRAL,
                  1.0F,
                  1.0F
               );
            } else {
               _level.playLocalSound(
                  x,
                  y,
                  z,
                  (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:jumpscare_sound_1")),
                  SoundSource.NEUTRAL,
                  1.0F,
                  1.0F,
                  false
               );
            }
         }

         if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && world instanceof ServerLevel _level) {
            LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
            entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z + 1.0)));
            entityToSpawn.setVisualOnly(true);
            _level.addFreshEntity(entityToSpawn);
         }
      }
   }
}
