package net.mcreator.ahorrormodtest.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap.Types;

public class GenerateScaryCrucifixProcedure {
   public static void execute(LevelAccessor world, double x, double z) {
      double tempHeight = 0.0;
      tempHeight = world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)x, (int)(z - 20.0));
      if (world.getBlockState(BlockPos.containing(x, tempHeight + 1.0, z - 20.0)).getBlock() == Blocks.AIR) {
         world.setBlock(BlockPos.containing(x, tempHeight + 1.0, z - 20.0), Blocks.COBBLESTONE.defaultBlockState(), 3);
      }

      if (world.getBlockState(BlockPos.containing(x, tempHeight + 2.0, z - 20.0)).getBlock() == Blocks.AIR) {
         world.setBlock(BlockPos.containing(x, tempHeight + 2.0, z - 20.0), Blocks.COBBLESTONE.defaultBlockState(), 3);
      }

      if (world.getBlockState(BlockPos.containing(x, tempHeight + 3.0, z - 20.0)).getBlock() == Blocks.AIR) {
         world.setBlock(BlockPos.containing(x, tempHeight + 3.0, z - 20.0), Blocks.COBBLESTONE.defaultBlockState(), 3);
      }

      if (world.getBlockState(BlockPos.containing(x, tempHeight + 4.0, z - 20.0)).getBlock() == Blocks.AIR) {
         world.setBlock(BlockPos.containing(x, tempHeight + 4.0, z - 20.0), Blocks.COBBLESTONE.defaultBlockState(), 3);
      }

      if (world.getBlockState(BlockPos.containing(x + 1.0, tempHeight + 3.0, z - 20.0)).getBlock() == Blocks.AIR) {
         world.setBlock(BlockPos.containing(x + 1.0, tempHeight + 3.0, z - 20.0), Blocks.COBBLESTONE.defaultBlockState(), 3);
      }

      if (world.getBlockState(BlockPos.containing(x - 1.0, tempHeight + 3.0, z - 20.0)).getBlock() == Blocks.AIR) {
         world.setBlock(BlockPos.containing(x - 1.0, tempHeight + 3.0, z - 20.0), Blocks.COBBLESTONE.defaultBlockState(), 3);
      }
   }
}
