package net.mcreator.ahorrormodtest.network;

import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModMenus;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModScreens;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.Identifier;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;

@EventBusSubscriber
public record MenuStateUpdateMessage(int elementType, String name, Object elementState) implements CustomPacketPayload {
   public static final Type<MenuStateUpdateMessage> TYPE = new Type(Identifier.fromNamespaceAndPath("thenewherobrinemod", "menustate_update"));
   public static final StreamCodec<RegistryFriendlyByteBuf, MenuStateUpdateMessage> STREAM_CODEC = StreamCodec.of(
      MenuStateUpdateMessage::write, MenuStateUpdateMessage::read
   );

   public static void write(FriendlyByteBuf buffer, MenuStateUpdateMessage message) {
      buffer.writeInt(message.elementType);
      buffer.writeUtf(message.name);
      if (message.elementType == 0) {
         buffer.writeUtf((String)message.elementState);
      } else if (message.elementType == 1) {
         buffer.writeBoolean((Boolean)message.elementState);
      }
   }

   public static MenuStateUpdateMessage read(FriendlyByteBuf buffer) {
      int elementType = buffer.readInt();
      String name = buffer.readUtf();
      Object elementState = null;
      if (elementType == 0) {
         elementState = buffer.readUtf();
      } else if (elementType == 1) {
         elementState = buffer.readBoolean();
      }

      return new MenuStateUpdateMessage(elementType, name, elementState);
   }

   public Type<MenuStateUpdateMessage> type() {
      return TYPE;
   }

   public static void handleMenuState(MenuStateUpdateMessage message, IPayloadContext context) {
      if (message.name.length() <= 256 && !(message.elementState instanceof String string && string.length() > 8192)) {
         context.enqueueWork(() -> {
            if (context.player().containerMenu instanceof ThenewherobrinemodModMenus.MenuAccessor menu) {
               menu.getMenuState().put(message.elementType + ":" + message.name, message.elementState);
               if (context.flow() == PacketFlow.CLIENTBOUND && Minecraft.getInstance().gui.screen() instanceof ThenewherobrinemodModScreens.ScreenAccessor accessor) {
                  accessor.updateMenuState(message.elementType, message.name, message.elementState);
               }
            }
         }).exceptionally(e -> {
            context.connection().disconnect(Component.literal(e.getMessage()));
            return null;
         });
      }
   }

   @SubscribeEvent
   public static void registerMessage(FMLCommonSetupEvent event) {
      ThenewherobrinemodMod.addNetworkMessage(TYPE, STREAM_CODEC, MenuStateUpdateMessage::handleMenuState);
   }
}
