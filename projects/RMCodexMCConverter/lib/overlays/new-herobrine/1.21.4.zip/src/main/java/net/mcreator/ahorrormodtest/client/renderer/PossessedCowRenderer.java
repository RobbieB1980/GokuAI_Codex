package net.mcreator.ahorrormodtest.client.renderer;

import net.mcreator.ahorrormodtest.entity.PossessedCowEntity;
import net.minecraft.client.model.animal.cow.CowModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class PossessedCowRenderer extends MobRenderer<PossessedCowEntity, LivingEntityRenderState, CowModel> {
   private PossessedCowEntity entity = null;

   public PossessedCowRenderer(Context context) {
      super(context, new CowModel(context.bakeLayer(ModelLayers.COW)), 0.5F);
   }

   public LivingEntityRenderState createRenderState() {
      return new LivingEntityRenderState();
   }

   public void extractRenderState(PossessedCowEntity entity, LivingEntityRenderState state, float partialTicks) {
      super.extractRenderState(entity, state, partialTicks);
      this.entity = entity;
   }

   public Identifier getTextureLocation(LivingEntityRenderState state) {
      return Identifier.parse("thenewherobrinemod:textures/entities/cow.png");
   }
}
