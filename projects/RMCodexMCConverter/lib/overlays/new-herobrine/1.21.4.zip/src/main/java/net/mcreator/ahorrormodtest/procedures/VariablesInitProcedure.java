package net.mcreator.ahorrormodtest.procedures;

import org.jetbrains.annotations.Nullable;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModGameRules;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;

@EventBusSubscriber
public class VariablesInitProcedure {
   @SubscribeEvent
   public static void onPlayerLoggedIn(PlayerLoggedInEvent event) {
      execute(event, event.getEntity().level());
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      if (ThenewherobrinemodModVariables.WorldVariables.get(world).First_Time == 1.0) {
         ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer_Time = world instanceof ServerLevel _serverLevelGR0
            ? _serverLevelGR0.getGameRules().get(ThenewherobrinemodModGameRules.TIME_BEFORE_HEROBRINE_FIRST_SPAWN.get())
            : 0.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         ThenewherobrinemodModVariables.WorldVariables.get(world).First_Time = 0.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 0.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times = 0.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
      }
   }
}
