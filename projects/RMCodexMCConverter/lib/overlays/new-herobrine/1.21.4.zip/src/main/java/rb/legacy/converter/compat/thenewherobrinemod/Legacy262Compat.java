package rb.legacy.converter.compat.thenewherobrinemod;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

/** Mechanical bridge for APIs removed between Minecraft 1.21.x and 26.2. Mod-scoped to avoid JPMS split packages. */
public final class Legacy262Compat {
    private Legacy262Compat() {}

    @SuppressWarnings("deprecation")
    public static List<BlockStateModelPart> modelParts(BlockStateModel model) {
        List<BlockStateModelPart> parts = new ArrayList<>();
        model.collectParts(RandomSource.create(), parts);
        return parts;
    }

    public static BlockState copyValue(BlockState target, Property.Value<?> value) {
        return copyCaptured(target, value);
    }

    @SuppressWarnings("unchecked")
    private static <T extends Comparable<T>> BlockState copyCaptured(BlockState target, Property.Value<T> value) {
        Property<T> property = (Property<T>) target.getBlock().getStateDefinition().getProperty(value.property().getName());
        return property == null ? target : target.setValue(property, value.value());
    }
}
