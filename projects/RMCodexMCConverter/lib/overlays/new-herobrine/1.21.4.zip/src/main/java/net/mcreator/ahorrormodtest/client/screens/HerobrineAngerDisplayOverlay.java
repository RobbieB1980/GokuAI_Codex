package net.mcreator.ahorrormodtest.client.screens;

import net.minecraft.network.chat.Component;

import net.mcreator.ahorrormodtest.procedures.AngerOverlayTextProcedure;
import net.mcreator.ahorrormodtest.procedures.HerobrineAngerShowProcedure;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderGuiEvent.Pre;

@EventBusSubscriber(Dist.CLIENT)
public class HerobrineAngerDisplayOverlay {
   @SubscribeEvent(priority = EventPriority.NORMAL)
   public static void eventHandler(Pre event) {
      int w = event.getGuiGraphics().guiWidth();
      int h = event.getGuiGraphics().guiHeight();
      Level world = null;
      double x = 0.0;
      double y = 0.0;
      double z = 0.0;
      Player entity = Minecraft.getInstance().player;
      if (entity != null) {
         world = entity.level();
         x = entity.getX();
         y = entity.getY();
         z = entity.getZ();
      }

      if (HerobrineAngerShowProcedure.execute(world)) {
         event.getGuiGraphics().text(Minecraft.getInstance().font, Component.literal(AngerOverlayTextProcedure.execute(world)), 3, 3, -1, false);
      }
   }
}
