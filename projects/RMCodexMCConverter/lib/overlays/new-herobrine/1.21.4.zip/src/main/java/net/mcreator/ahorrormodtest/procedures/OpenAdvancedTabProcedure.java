package net.mcreator.ahorrormodtest.procedures;

import io.netty.buffer.Unpooled;
import net.mcreator.ahorrormodtest.world.inventory.ConfigUIAdvancedMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.LevelAccessor;

public class OpenAdvancedTabProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (getEntityGameType(entity) == GameType.CREATIVE && entity instanceof ServerPlayer _ent) {
            final BlockPos _bpos = BlockPos.containing(x, y, z);
            _ent.openMenu(new MenuProvider() {
               public Component getDisplayName() {
                  return Component.literal("ConfigUIAdvanced");
               }

               public boolean shouldTriggerClientSideContainerClosingOnOpen() {
                  return false;
               }

               public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
                  return new ConfigUIAdvancedMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
               }
            }, _bpos);
         }
      }
   }

   private static GameType getEntityGameType(Entity entity) {
      if (entity instanceof ServerPlayer serverPlayer) {
         return serverPlayer.gameMode.getGameModeForPlayer();
      } else {
         if (entity instanceof Player player && player.level().isClientSide()) {
            PlayerInfo playerInfo = Minecraft.getInstance().getConnection().getPlayerInfo(player.getGameProfile().id());
            if (playerInfo != null) {
               return playerInfo.getGameMode();
            }
         }

         return null;
      }
   }
}
