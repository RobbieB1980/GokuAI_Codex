package net.mcreator.ahorrormodtest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModBlocks;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModEntities;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModItems;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModMenus;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModSounds;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModTabs;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModGameRules;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.util.thread.SidedThreadGroups;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.ServerTickEvent.Post;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadHandler;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod("thenewherobrinemod")
public class ThenewherobrinemodMod {
   public static final Logger LOGGER = LogManager.getLogger(ThenewherobrinemodMod.class);
   public static final String MODID = "thenewherobrinemod";
   private static boolean networkingRegistered = false;
   private static final Map<Type<?>, ThenewherobrinemodMod.NetworkMessage<?>> MESSAGES = new HashMap<>();
   private static final Collection<Object[]> workQueue = new ConcurrentLinkedQueue<>();

   public ThenewherobrinemodMod(IEventBus modEventBus) {
      NeoForge.EVENT_BUS.register(this);
      modEventBus.addListener(this::registerNetworking);
      ThenewherobrinemodModSounds.REGISTRY.register(modEventBus);
      ThenewherobrinemodModBlocks.REGISTRY.register(modEventBus);
      ThenewherobrinemodModItems.REGISTRY.register(modEventBus);
      ThenewherobrinemodModEntities.REGISTRY.register(modEventBus);
      ThenewherobrinemodModTabs.REGISTRY.register(modEventBus);
      ThenewherobrinemodModVariables.ATTACHMENT_TYPES.register(modEventBus);
      ThenewherobrinemodModMenus.REGISTRY.register(modEventBus);
      ThenewherobrinemodModGameRules.REGISTRY.register(modEventBus);
   }

   public static <T extends CustomPacketPayload> void addNetworkMessage(
      Type<T> id, StreamCodec<? super RegistryFriendlyByteBuf, T> reader, IPayloadHandler<T> handler
   ) {
      if (networkingRegistered) {
         throw new IllegalStateException("Cannot register new network messages after networking has been registered");
      }

      MESSAGES.put(id, new ThenewherobrinemodMod.NetworkMessage(reader, handler));
   }

   private void registerNetworking(RegisterPayloadHandlersEvent event) {
      PayloadRegistrar registrar = event.registrar("thenewherobrinemod");
      for (var entry : MESSAGES.entrySet()) {
         registerOne(registrar, entry.getKey(), entry.getValue());
      }
      networkingRegistered = true;
   }

   @SuppressWarnings("unchecked")
   private static <T extends CustomPacketPayload> void registerOne(
      PayloadRegistrar registrar, Type<?> id, ThenewherobrinemodMod.NetworkMessage<?> message
   ) {
      IPayloadHandler<T> handler = (IPayloadHandler<T>)message.handler();
      registrar.playBidirectional(
         (Type<T>)id,
         (StreamCodec<? super RegistryFriendlyByteBuf, T>)message.reader(),
         handler,
         handler
      );
   }

   public static void queueServerWork(int tick, Runnable action) {
      if (Thread.currentThread().getThreadGroup() == SidedThreadGroups.SERVER) {
         workQueue.add(new Object[] { action, tick });
      }
   }

   @SubscribeEvent
   public void tick(Post event) {
      List<Object[]> actions = new ArrayList<>();
      workQueue.forEach(work -> {
         work[1] = (Integer)work[1] - 1;
         if ((Integer)work[1] == 0) {
            actions.add(work);
         }
      });
      actions.forEach(e -> ((Runnable)e[0]).run());
      workQueue.removeAll(actions);
   }

   private record NetworkMessage<T extends CustomPacketPayload>(StreamCodec<? super RegistryFriendlyByteBuf, T> reader, IPayloadHandler<T> handler) {
   }
}
