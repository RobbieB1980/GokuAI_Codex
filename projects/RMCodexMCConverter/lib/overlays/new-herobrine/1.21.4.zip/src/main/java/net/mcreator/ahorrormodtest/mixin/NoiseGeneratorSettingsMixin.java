package net.mcreator.ahorrormodtest.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModBiomes;
import net.minecraft.core.Holder;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.levelgen.SurfaceRules.RuleSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements ThenewherobrinemodModBiomes.ThenewherobrinemodModNoiseGeneratorSettings {
   @Unique
   private Holder<DimensionType> thenewherobrinemod_dimensionTypeReference;

   @WrapMethod(method = "surfaceRule")
   public RuleSource surfaceRule(Operation<RuleSource> original) {
      RuleSource retval = (RuleSource)original.call(new Object[0]);
      if (this.thenewherobrinemod_dimensionTypeReference != null) {
         retval = ThenewherobrinemodModBiomes.adaptSurfaceRule(retval, this.thenewherobrinemod_dimensionTypeReference);
      }

      return retval;
   }

   @Override
   public void setthenewherobrinemodDimensionTypeReference(Holder<DimensionType> dimensionType) {
      this.thenewherobrinemod_dimensionTypeReference = dimensionType;
   }
}
