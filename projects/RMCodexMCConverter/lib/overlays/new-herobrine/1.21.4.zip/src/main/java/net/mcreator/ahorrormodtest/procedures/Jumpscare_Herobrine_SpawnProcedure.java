package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;

public class Jumpscare_Herobrine_SpawnProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (world instanceof Level _level) {
            if (!_level.isClientSide()) {
               _level.playSound(
                  null,
                  BlockPos.containing(x, y, z),
                  (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:jumpscare_sound_1")),
                  SoundSource.NEUTRAL,
                  3.0F,
                  1.0F
               );
            } else {
               _level.playLocalSound(
                  x,
                  y,
                  z,
                  (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:jumpscare_sound_1")),
                  SoundSource.NEUTRAL,
                  3.0F,
                  1.0F,
                  false
               );
            }
         }

         if (world instanceof Level _level) {
            if (!_level.isClientSide()) {
               _level.playSound(
                  null,
                  BlockPos.containing(x, y, z),
                  (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                  SoundSource.HOSTILE,
                  1.0F,
                  1.0F
               );
            } else {
               _level.playLocalSound(
                  x, y, z, (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")), SoundSource.HOSTILE, 1.0F, 1.0F, false
               );
            }
         }

         ThenewherobrinemodMod.queueServerWork(20, () -> {
            if (world instanceof ServerLevel _levelx) {
               LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_levelx, EntitySpawnReason.TRIGGERED);
               entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
               entityToSpawn.setVisualOnly(true);
               _levelx.addFreshEntity(entityToSpawn);
            }

            if (!entity.level().isClientSide()) {
               entity.discard();
            }
         });
         if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
            EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
         }
      }
   }
}
