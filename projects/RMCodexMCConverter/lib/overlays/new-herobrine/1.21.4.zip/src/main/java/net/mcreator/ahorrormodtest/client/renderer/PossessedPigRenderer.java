package net.mcreator.ahorrormodtest.client.renderer;

import net.mcreator.ahorrormodtest.entity.PossessedPigEntity;
import net.minecraft.client.model.animal.pig.PigModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class PossessedPigRenderer extends MobRenderer<PossessedPigEntity, LivingEntityRenderState, PigModel> {
   private PossessedPigEntity entity = null;

   public PossessedPigRenderer(Context context) {
      super(context, new PigModel(context.bakeLayer(ModelLayers.PIG)), 0.5F);
   }

   public LivingEntityRenderState createRenderState() {
      return new LivingEntityRenderState();
   }

   public void extractRenderState(PossessedPigEntity entity, LivingEntityRenderState state, float partialTicks) {
      super.extractRenderState(entity, state, partialTicks);
      this.entity = entity;
   }

   public Identifier getTextureLocation(LivingEntityRenderState state) {
      return Identifier.parse("thenewherobrinemod:textures/entities/possessed_pig.png");
   }
}
