package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;

public class ACTIONEvent3Procedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (world instanceof ServerLevel _level) {
            LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
            entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z - 20.0)));
            entityToSpawn.setVisualOnly(true);
            _level.addFreshEntity(entityToSpawn);
         }

         if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_CrucifixSpawn == 1.0) {
            GenerateScaryCrucifixProcedure.execute(world, x, z);
         } else if (world instanceof ServerLevel _level) {
            LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
            entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
            _level.addFreshEntity(entityToSpawn);
         }

         if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0
            && Mth.nextDouble(RandomSource.create(), 1.0, 2.0) == 2.0) {
            EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes = 0.0;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_JumpscaresEnabled == 1.0
            && Mth.nextDouble(RandomSource.create(), 1.0, 2.0) == 2.0) {
            EVENTSJumpscareHerobrineProcedure.execute(world, entity);
            ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineBehindEnabled == 1.0
            && Mth.nextDouble(RandomSource.create(), 1.0, 2.0) == 2.0) {
            EVENTSHerobrineBehindNormalSpawnProcedure.execute(world, x, z, entity);
            ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         } else {
            ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         }
      }
   }
}
