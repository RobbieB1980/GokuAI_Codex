package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.level.LevelAccessor;

public class HerobrineAttacksEnabledProcedure {
   public static boolean execute(LevelAccessor world) {
      boolean attacksEnabled = false;
      if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineAttackEnabled == 1.0) {
         attacksEnabled = true;
      } else {
         attacksEnabled = false;
      }

      return attacksEnabled;
   }
}
