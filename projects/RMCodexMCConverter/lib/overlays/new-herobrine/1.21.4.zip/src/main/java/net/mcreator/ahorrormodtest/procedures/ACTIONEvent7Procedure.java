package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;

public class ACTIONEvent7Procedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (world.getBlockState(BlockPos.containing(x, y + 1.0, z)).getBlock() == Blocks.AIR) {
            world.setBlock(BlockPos.containing(x, y + 1.0, z), Blocks.COBWEB.defaultBlockState(), 3);
         } else if (world.getBlockState(BlockPos.containing(x, y, z)).getBlock() == Blocks.AIR) {
            world.setBlock(BlockPos.containing(x, y, z), Blocks.COBWEB.defaultBlockState(), 3);
         } else {
            if (entity instanceof Player _player) {
               _player.getFoodData().setSaturation(0.0F);
            }

            if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 0.5) {
               entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.MOB_ATTACK)), 6.0F);
            } else {
               entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.MOB_ATTACK)), 3.0F);
            }

            if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
               if (world instanceof Level _level) {
                  if (!_level.isClientSide()) {
                     _level.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:long_glitch_sound_effect")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _level.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:long_glitch_sound_effect")),
                        SoundSource.NEUTRAL,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }
            } else if (world instanceof Level _level) {
               if (!_level.isClientSide()) {
                  _level.playSound(
                     null,
                     BlockPos.containing(x, y, z),
                     (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:connexion_glitch_sound_effect")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F
                  );
               } else {
                  _level.playLocalSound(
                     x,
                     y,
                     z,
                     (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:connexion_glitch_sound_effect")),
                     SoundSource.NEUTRAL,
                     1.0F,
                     1.0F,
                     false
                  );
               }
            }
         }

         ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
      }
   }
}
