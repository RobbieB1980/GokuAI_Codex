package net.mcreator.ahorrormodtest.network;

import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.mcreator.ahorrormodtest.procedures.OpenAdvancedTabProcedure;
import net.mcreator.ahorrormodtest.procedures.OpenHerobrineTabProcedure;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;

@EventBusSubscriber
public record ConfigUIStructuresButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {
   public static final Type<ConfigUIStructuresButtonMessage> TYPE = new Type(
      Identifier.fromNamespaceAndPath("thenewherobrinemod", "config_ui_structures_buttons")
   );
   public static final StreamCodec<RegistryFriendlyByteBuf, ConfigUIStructuresButtonMessage> STREAM_CODEC = StreamCodec.of((buffer, message) -> {
      buffer.writeInt(message.buttonID);
      buffer.writeInt(message.x);
      buffer.writeInt(message.y);
      buffer.writeInt(message.z);
   }, buffer -> new ConfigUIStructuresButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));

   public Type<ConfigUIStructuresButtonMessage> type() {
      return TYPE;
   }

   public static void handleData(ConfigUIStructuresButtonMessage message, IPayloadContext context) {
      if (context.flow() == PacketFlow.SERVERBOUND) {
         context.enqueueWork(() -> handleButtonAction(context.player(), message.buttonID, message.x, message.y, message.z)).exceptionally(e -> {
            context.connection().disconnect(Component.literal(e.getMessage()));
            return null;
         });
      }
   }

   public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
      Level world = entity.level();
      if (world.hasChunkAt(new BlockPos(x, y, z))) {
         if (buttonID == 0) {
            OpenHerobrineTabProcedure.execute(world, x, y, z, entity);
         }

         if (buttonID == 2) {
            OpenAdvancedTabProcedure.execute(world, x, y, z, entity);
         }
      }
   }

   @SubscribeEvent
   public static void registerMessage(FMLCommonSetupEvent event) {
      ThenewherobrinemodMod.addNetworkMessage(TYPE, STREAM_CODEC, ConfigUIStructuresButtonMessage::handleData);
   }
}
