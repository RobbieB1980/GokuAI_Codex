package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.level.LevelAccessor;

public class HerobrineAngerDisplayCheckBoxEnabledProcedure {
   public static boolean execute(LevelAccessor world) {
      boolean AngerDisplayEnabled = false;
      if (ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineAngerDisplayConfirmed == 1.0) {
         AngerDisplayEnabled = true;
      } else {
         AngerDisplayEnabled = false;
      }

      return AngerDisplayEnabled;
   }
}
