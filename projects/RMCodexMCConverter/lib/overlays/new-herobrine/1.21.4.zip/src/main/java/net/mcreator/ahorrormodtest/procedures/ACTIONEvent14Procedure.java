package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModEntities;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public class ACTIONEvent14Procedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         double xIndex = 0.0;
         if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
            _entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 1));
         }

         xIndex = -5.0;

         for (int index0 = 0; index0 < 10; index0++) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                  .spawn(_level, BlockPos.containing(x + xIndex, y, z + 7.0), EntitySpawnReason.MOB_SUMMONED);
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }

            xIndex++;
         }

         xIndex = -5.0;

         for (int index1 = 0; index1 < 10; index1++) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                  .spawn(_level, BlockPos.containing(x + xIndex, y, z - 7.0), EntitySpawnReason.MOB_SUMMONED);
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }

            xIndex++;
         }

         xIndex = -5.0;

         for (int index2 = 0; index2 < 10; index2++) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                  .spawn(_level, BlockPos.containing(x + 7.0, y, z + xIndex), EntitySpawnReason.MOB_SUMMONED);
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot() + 90.0F);
                  entityToSpawn.setYBodyRot(entity.getYRot() + 90.0F);
                  entityToSpawn.setYHeadRot(entity.getYRot() + 90.0F);
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }

            xIndex++;
         }

         xIndex = -5.0;

         for (int index3 = 0; index3 < 10; index3++) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                  .spawn(_level, BlockPos.containing(x - 7.0, y, z + xIndex), EntitySpawnReason.MOB_SUMMONED);
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot() - 90.0F);
                  entityToSpawn.setYBodyRot(entity.getYRot() - 90.0F);
                  entityToSpawn.setYHeadRot(entity.getYRot() - 90.0F);
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }

            xIndex++;
         }

         for (int index4 = 0; index4 < 3; index4++) {
            ThenewherobrinemodMod.queueServerWork(
               6,
               () -> entity.hurt(
                  new DamageSource(world.holderOrThrow(DamageTypes.MOB_ATTACK)),
                  ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger <= 0.9 ? 1 : 2
               )
            );
         }

         ThenewherobrinemodModVariables.WorldVariables.get(world).TEMP_CurrentWorldHourTemp = (world instanceof net.minecraft.world.level.Level _lvlDay ? _lvlDay.getOverworldClockTime() : 0L);
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         if (world instanceof ServerLevel _level) {
            _level.getServer()
               .getCommands()
               .performPrefixedCommand(
                  new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, net.minecraft.server.permissions.LevelBasedPermissionSet.OWNER, "", Component.literal(""), _level.getServer(), null)
                     .withSuppressedOutput(),
                  "time set night"
               );
         }

         ThenewherobrinemodMod.queueServerWork(
            20,
            () -> {
               if (world instanceof ServerLevel _levelx) {
                  _levelx.getServer()
                     .getCommands()
                     .performPrefixedCommand(
                        new CommandSourceStack(
                              CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _levelx, net.minecraft.server.permissions.LevelBasedPermissionSet.OWNER, "", Component.literal(""), _levelx.getServer(), null
                           )
                           .withSuppressedOutput(),
                        "time set " + ThenewherobrinemodModVariables.WorldVariables.get(world).TEMP_CurrentWorldHourTemp
                     );
               }
            }
         );
      }
   }
}
