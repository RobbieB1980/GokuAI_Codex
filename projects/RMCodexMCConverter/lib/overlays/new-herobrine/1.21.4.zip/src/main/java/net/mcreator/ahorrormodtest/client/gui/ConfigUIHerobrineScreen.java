package net.mcreator.ahorrormodtest.client.gui;


import net.minecraft.client.input.KeyEvent;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModScreens;
import net.mcreator.ahorrormodtest.network.ConfigUIHerobrineButtonMessage;
import net.mcreator.ahorrormodtest.procedures.HerobrineAngerDisplayCheckBoxEnabledProcedure;
import net.mcreator.ahorrormodtest.procedures.HerobrineAttacksEnabledProcedure;
import net.mcreator.ahorrormodtest.procedures.JumpscaresCheckBoxEnabledProcedure;
import net.mcreator.ahorrormodtest.procedures.PassiveWatchingCheckboxEnabledProcedure;
import net.mcreator.ahorrormodtest.procedures.ShowCreativeOnlyProcedure;
import net.mcreator.ahorrormodtest.procedures.SpawnBehindPlayerEnabledProcedure;
import net.mcreator.ahorrormodtest.world.inventory.ConfigUIHerobrineMenu;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

public class ConfigUIHerobrineScreen extends AbstractContainerScreen<ConfigUIHerobrineMenu> implements ThenewherobrinemodModScreens.ScreenAccessor {
   private final Level world;
   private final int x;
   private final int y;
   private final int z;
   private final Player entity;
   private boolean menuStateUpdateActive = false;
   Checkbox JumpscaresEnabledCheckBox;
   Checkbox FarHerobrineEnabledCheckBox;
   Checkbox SpawnBehindCheckBox;
   Checkbox HerobrineAttackEnabledCheckBox;
   Checkbox HerobrineAngerDisplayEnabledCheckBox;
   Button button_herobrine;
   Button button_structures;
   Button button_advanced;
   Button button_empty;
   private static final Identifier texture = Identifier.parse("thenewherobrinemod:textures/screens/config_ui_herobrine.png");

   public ConfigUIHerobrineScreen(ConfigUIHerobrineMenu container, Inventory inventory, Component text) {
      super(container, inventory, text, 250, 180);
      this.world = container.world;
      this.x = container.x;
      this.y = container.y;
      this.z = container.z;
      this.entity = container.entity;
   }

   @Override
   public void updateMenuState(int elementType, String name, Object elementState) {
      this.menuStateUpdateActive = true;
      this.menuStateUpdateActive = false;
   }

   public void extractRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
      super.extractRenderState(guiGraphics, mouseX, mouseY, partialTicks);
      boolean customTooltipShown = false;
      if (ShowCreativeOnlyProcedure.execute(this.entity)
         && mouseX > this.leftPos + 192
         && mouseX < this.leftPos + 216
         && mouseY > this.topPos + 28
         && mouseY < this.topPos + 52) {
         guiGraphics.setTooltipForNextFrame(
            this.font, Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.tooltip_available_in_creative_mode_only"), mouseX, mouseY
         );
         customTooltipShown = true;
      }

      if (!customTooltipShown) {
         this.extractTooltip(guiGraphics, mouseX, mouseY);
      }
   }

   public void extractBackground(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
      guiGraphics.blit(
         net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, this.leftPos, this.topPos, 0.0F, 0.0F, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight
      );
   }

   public boolean keyPressed(KeyEvent event) {
      if (event.key() == 256) {
         this.minecraft.player.closeContainer();
         return true;
      } else {
         return super.keyPressed(event);
      }
   }

   protected void extractLabels(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY) {
      guiGraphics.text(this.font, Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.label_empty"), 15, 21, -12829636, false);
      guiGraphics.text(
         this.font, Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.label_disabling_everything_will_preven"), -23, 186, -65536, false
      );
   }

   public void init() {
      super.init();
      this.button_herobrine = Button.builder(Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.button_herobrine"), e -> {})
         .bounds(this.leftPos + 10, this.topPos + 6, 72, 20)
         .build();
      this.addRenderableWidget(this.button_herobrine);
      this.button_structures = Button.builder(Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.button_structures"), e -> {
         int x = this.x;
         int y = this.y;
         ClientPacketDistributor.sendToServer(new ConfigUIHerobrineButtonMessage(1, x, y, this.z), new CustomPacketPayload[0]);
         ConfigUIHerobrineButtonMessage.handleButtonAction(this.entity, 1, x, y, this.z);
      }).bounds(this.leftPos + 89, this.topPos + 6, 77, 20).build();
      this.addRenderableWidget(this.button_structures);
      this.button_advanced = Button.builder(Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.button_advanced"), e -> {
         int x = this.x;
         int y = this.y;
         ClientPacketDistributor.sendToServer(new ConfigUIHerobrineButtonMessage(2, x, y, this.z), new CustomPacketPayload[0]);
         ConfigUIHerobrineButtonMessage.handleButtonAction(this.entity, 2, x, y, this.z);
      }).bounds(this.leftPos + 172, this.topPos + 6, 67, 20).build();
      this.addRenderableWidget(this.button_advanced);
      this.button_empty = Button.builder(Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.button_empty"), e -> {})
         .bounds(this.leftPos + 190, this.topPos + 31, 30, 20)
         .build();
      this.addRenderableWidget(this.button_empty);
      boolean JumpscaresEnabledCheckBoxSelected = JumpscaresCheckBoxEnabledProcedure.execute(this.world);
      this.JumpscaresEnabledCheckBox = Checkbox.builder(
            Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.JumpscaresEnabledCheckBox"), this.font
         )
         .pos(this.leftPos + 10, this.topPos + 46)
         .onValueChange((checkbox, value) -> {
            if (!this.menuStateUpdateActive) {
               ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "JumpscaresEnabledCheckBox", value, false);
            }
         })
         .selected(JumpscaresEnabledCheckBoxSelected)
         .build();
      if (JumpscaresEnabledCheckBoxSelected) {
         ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "JumpscaresEnabledCheckBox", true, false);
      }

      this.addRenderableWidget(this.JumpscaresEnabledCheckBox);
      boolean FarHerobrineEnabledCheckBoxSelected = PassiveWatchingCheckboxEnabledProcedure.execute(this.world);
      this.FarHerobrineEnabledCheckBox = Checkbox.builder(
            Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.FarHerobrineEnabledCheckBox"), this.font
         )
         .pos(this.leftPos + 10, this.topPos + 71)
         .onValueChange((checkbox, value) -> {
            if (!this.menuStateUpdateActive) {
               ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "FarHerobrineEnabledCheckBox", value, false);
            }
         })
         .selected(FarHerobrineEnabledCheckBoxSelected)
         .build();
      if (FarHerobrineEnabledCheckBoxSelected) {
         ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "FarHerobrineEnabledCheckBox", true, false);
      }

      this.addRenderableWidget(this.FarHerobrineEnabledCheckBox);
      boolean SpawnBehindCheckBoxSelected = SpawnBehindPlayerEnabledProcedure.execute(this.world);
      this.SpawnBehindCheckBox = Checkbox.builder(Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.SpawnBehindCheckBox"), this.font)
         .pos(this.leftPos + 10, this.topPos + 96)
         .onValueChange((checkbox, value) -> {
            if (!this.menuStateUpdateActive) {
               ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "SpawnBehindCheckBox", value, false);
            }
         })
         .selected(SpawnBehindCheckBoxSelected)
         .build();
      if (SpawnBehindCheckBoxSelected) {
         ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "SpawnBehindCheckBox", true, false);
      }

      this.addRenderableWidget(this.SpawnBehindCheckBox);
      boolean HerobrineAttackEnabledCheckBoxSelected = HerobrineAttacksEnabledProcedure.execute(this.world);
      this.HerobrineAttackEnabledCheckBox = Checkbox.builder(
            Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.HerobrineAttackEnabledCheckBox"), this.font
         )
         .pos(this.leftPos + 10, this.topPos + 121)
         .onValueChange((checkbox, value) -> {
            if (!this.menuStateUpdateActive) {
               ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "HerobrineAttackEnabledCheckBox", value, false);
            }
         })
         .selected(HerobrineAttackEnabledCheckBoxSelected)
         .build();
      if (HerobrineAttackEnabledCheckBoxSelected) {
         ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "HerobrineAttackEnabledCheckBox", true, false);
      }

      this.addRenderableWidget(this.HerobrineAttackEnabledCheckBox);
      boolean HerobrineAngerDisplayEnabledCheckBoxSelected = HerobrineAngerDisplayCheckBoxEnabledProcedure.execute(this.world);
      this.HerobrineAngerDisplayEnabledCheckBox = Checkbox.builder(
            Component.translatable("gui.thenewherobrinemod.config_ui_herobrine.HerobrineAngerDisplayEnabledCheckBox"), this.font
         )
         .pos(this.leftPos + 10, this.topPos + 146)
         .onValueChange((checkbox, value) -> {
            if (!this.menuStateUpdateActive) {
               ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "HerobrineAngerDisplayEnabledCheckBox", value, false);
            }
         })
         .selected(HerobrineAngerDisplayEnabledCheckBoxSelected)
         .build();
      if (HerobrineAngerDisplayEnabledCheckBoxSelected) {
         ((ConfigUIHerobrineMenu)this.menu).sendMenuStateUpdate(this.entity, 1, "HerobrineAngerDisplayEnabledCheckBox", true, false);
      }

      this.addRenderableWidget(this.HerobrineAngerDisplayEnabledCheckBox);
   }

   protected void containerTick() {
      super.containerTick();
      this.button_empty.visible = ShowCreativeOnlyProcedure.execute(this.entity);
   }
}
