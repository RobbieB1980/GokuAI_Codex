package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;

public class CowTestPlayerKilledEventProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger < 1.4) {
            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger += 0.006;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer_Time != 12000.0) {
               AccelerateEventsProcedure.execute(world, x, y, z, entity);
            }
         }
      }
   }
}
