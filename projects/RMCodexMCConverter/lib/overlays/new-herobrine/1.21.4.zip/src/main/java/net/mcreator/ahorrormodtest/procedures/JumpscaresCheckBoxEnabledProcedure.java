package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.level.LevelAccessor;

public class JumpscaresCheckBoxEnabledProcedure {
   public static boolean execute(LevelAccessor world) {
      boolean IsJumpscareEnabled = false;
      if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_JumpscaresEnabled == 1.0) {
         IsJumpscareEnabled = true;
      } else {
         IsJumpscareEnabled = false;
      }

      return IsJumpscareEnabled;
   }
}
