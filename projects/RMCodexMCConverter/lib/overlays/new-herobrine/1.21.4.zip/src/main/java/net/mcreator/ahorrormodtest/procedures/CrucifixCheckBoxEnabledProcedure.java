package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.level.LevelAccessor;

public class CrucifixCheckBoxEnabledProcedure {
   public static boolean execute(LevelAccessor world) {
      boolean IsCrucifixEnabled = false;
      if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_CrucifixSpawn == 1.0) {
         IsCrucifixEnabled = true;
      } else {
         IsCrucifixEnabled = false;
      }

      return IsCrucifixEnabled;
   }
}
