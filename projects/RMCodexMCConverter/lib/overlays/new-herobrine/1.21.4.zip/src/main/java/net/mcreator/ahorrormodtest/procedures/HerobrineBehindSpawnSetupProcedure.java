package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;

public class HerobrineBehindSpawnSetupProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (entity.getDirection() == Direction.NORTH) {
            ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineBehindOrientation = Direction.SOUTH;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         } else if (entity.getDirection() == Direction.SOUTH) {
            ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineBehindOrientation = Direction.NORTH;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         } else if (entity.getDirection() == Direction.WEST) {
            ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineBehindOrientation = Direction.EAST;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         } else {
            ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineBehindOrientation = Direction.WEST;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         }
      }
   }
}
