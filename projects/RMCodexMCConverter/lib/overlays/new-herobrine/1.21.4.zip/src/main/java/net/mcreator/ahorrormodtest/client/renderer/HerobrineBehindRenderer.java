package net.mcreator.ahorrormodtest.client.renderer;

import net.minecraft.client.renderer.rendertype.RenderTypes;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.mcreator.ahorrormodtest.entity.HerobrineBehindEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;

public class HerobrineBehindRenderer extends HumanoidMobRenderer<HerobrineBehindEntity, HumanoidRenderState, HumanoidModel<HumanoidRenderState>> {
   private HerobrineBehindEntity entity = null;

   public HerobrineBehindRenderer(Context context) {
      super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
      this.addLayer(
         new HumanoidArmorLayer(this, net.minecraft.client.renderer.entity.ArmorModelSet.bake(ModelLayers.PLAYER_ARMOR, context.getModelSet(), HumanoidModel::new), context.getEquipmentRenderer())
      );
      this.addLayer(new RenderLayer<HumanoidRenderState, HumanoidModel<HumanoidRenderState>>(this) {
         final Identifier LAYER_TEXTURE = Identifier.parse("thenewherobrinemod:textures/entities/herobrine_eyes.png");

         public void submit(PoseStack poseStack, SubmitNodeCollector bufferSource, int light, HumanoidRenderState state, float headYaw, float headPitch) {
            bufferSource.order(0).submitModel(this.getParentModel(), state, poseStack, RenderTypes.eyes(this.LAYER_TEXTURE), light, LivingEntityRenderer.getOverlayCoords(state, 0.0F), -1, null, state.outlineColor, null);
         }
      });
   }

   public HumanoidRenderState createRenderState() {
      return new HumanoidRenderState();
   }

   public void extractRenderState(HerobrineBehindEntity entity, HumanoidRenderState state, float partialTicks) {
      super.extractRenderState(entity, state, partialTicks);
      this.entity = entity;
   }

   public Identifier getTextureLocation(HumanoidRenderState state) {
      return Identifier.parse("thenewherobrinemod:textures/entities/herobrine.png");
   }
}
