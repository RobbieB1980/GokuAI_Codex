package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModEntities;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public class EVENTSFarHerobrineNormalSpawnProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         double Far_Herobrine_Anger_Z_Distance = 0.0;
         double xIndex = 0.0;
         double yIndex = 0.0;
         double zIndex = 0.0;
         double tempZplayerPos = 0.0;
         double tempYplayerPos = 0.0;
         double tempXplayerPos = 0.0;
         double spawned = 0.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         Far_Herobrine_Anger_Z_Distance = Mth.nextInt(RandomSource.create(), 5, 10);
         if (entity.getDirection() == Direction.NORTH) {
            if (world.canSeeSkyFromBelowWater(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ() - Far_Herobrine_Anger_Z_Distance))) {
               if (world instanceof ServerLevel _level) {
                  Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                     .spawn(
                        _level,
                        BlockPos.containing(
                           entity.getX(),
                           world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)entity.getX(), (int)(entity.getZ() - Far_Herobrine_Anger_Z_Distance)) + 1,
                           entity.getZ() - Far_Herobrine_Anger_Z_Distance
                        ),
                        EntitySpawnReason.MOB_SUMMONED
                     );
                  if (entityToSpawn != null) {
                     entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                     entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                     entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                     entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
                  }
               }
            } else {
               tempXplayerPos = entity.getX();
               tempYplayerPos = entity.getY();
               tempZplayerPos = entity.getZ();
               spawned = 0.0;
               xIndex = tempXplayerPos;
               yIndex = tempYplayerPos + 10.0;
               zIndex = tempZplayerPos - 8.0;

               for (int index0 = 0; index0 < 6; index0++) {
                  while (yIndex > tempYplayerPos - 10.0) {
                     if (world.getBlockState(BlockPos.containing(xIndex, --yIndex, zIndex)).getBlock() == Blocks.AIR) {
                        if (world instanceof ServerLevel _level) {
                           Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                              .spawn(_level, BlockPos.containing(xIndex, yIndex, zIndex), EntitySpawnReason.MOB_SUMMONED);
                           if (entityToSpawn != null) {
                              entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                              entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                              entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                              entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
                           }
                        }

                        spawned = 1.0;
                        break;
                     }
                  }

                  if (spawned == 1.0) {
                     break;
                  }

                  zIndex--;
               }
            }
         } else if (entity.getDirection() == Direction.SOUTH) {
            if (world.canSeeSkyFromBelowWater(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ() + Far_Herobrine_Anger_Z_Distance))) {
               if (world instanceof ServerLevel _level) {
                  Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                     .spawn(
                        _level,
                        BlockPos.containing(
                           entity.getX(),
                           world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)entity.getX(), (int)(entity.getZ() + Far_Herobrine_Anger_Z_Distance)) + 1,
                           entity.getZ() + Far_Herobrine_Anger_Z_Distance
                        ),
                        EntitySpawnReason.MOB_SUMMONED
                     );
                  if (entityToSpawn != null) {
                     entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                     entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                     entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                     entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
                  }
               }
            } else {
               tempXplayerPos = entity.getX();
               tempYplayerPos = entity.getY();
               tempZplayerPos = entity.getZ();
               xIndex = tempXplayerPos;
               yIndex = tempYplayerPos + 10.0;
               zIndex = tempZplayerPos + 8.0;

               for (int index2 = 0; index2 < 6; index2++) {
                  while (yIndex > tempYplayerPos - 10.0) {
                     if (world.getBlockState(BlockPos.containing(xIndex, --yIndex, zIndex)).getBlock() == Blocks.AIR) {
                        if (world instanceof ServerLevel _level) {
                           Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                              .spawn(_level, BlockPos.containing(xIndex, yIndex, zIndex), EntitySpawnReason.MOB_SUMMONED);
                           if (entityToSpawn != null) {
                              entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                              entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                              entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                              entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
                           }
                        }

                        spawned = 1.0;
                        break;
                     }
                  }

                  if (spawned == 1.0) {
                     break;
                  }

                  zIndex++;
               }
            }
         } else if (entity.getDirection() == Direction.WEST) {
            if (world.canSeeSkyFromBelowWater(BlockPos.containing(entity.getX() - Far_Herobrine_Anger_Z_Distance, entity.getY(), entity.getZ()))) {
               if (world instanceof ServerLevel _level) {
                  Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                     .spawn(
                        _level,
                        BlockPos.containing(
                           entity.getX() - Far_Herobrine_Anger_Z_Distance,
                           world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)(entity.getX() - Far_Herobrine_Anger_Z_Distance), (int)entity.getZ()) + 1,
                           entity.getZ()
                        ),
                        EntitySpawnReason.MOB_SUMMONED
                     );
                  if (entityToSpawn != null) {
                     entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                     entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                     entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                     entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
                  }
               }
            } else {
               tempXplayerPos = entity.getX() - 8.0;
               tempYplayerPos = entity.getY();
               tempZplayerPos = entity.getZ();
               xIndex = tempXplayerPos;
               yIndex = tempYplayerPos + 10.0;
               zIndex = tempZplayerPos;

               for (int index4 = 0; index4 < 6; index4++) {
                  while (yIndex > tempYplayerPos - 10.0) {
                     if (world.getBlockState(BlockPos.containing(xIndex, --yIndex, zIndex)).getBlock() == Blocks.AIR) {
                        if (world instanceof ServerLevel _level) {
                           Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                              .spawn(_level, BlockPos.containing(xIndex, yIndex, zIndex), EntitySpawnReason.MOB_SUMMONED);
                           if (entityToSpawn != null) {
                              entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                              entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                              entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                              entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
                           }
                        }

                        spawned = 1.0;
                        break;
                     }
                  }

                  if (spawned == 1.0) {
                     break;
                  }

                  xIndex--;
               }
            }
         } else if (world.canSeeSkyFromBelowWater(BlockPos.containing(entity.getX() + Far_Herobrine_Anger_Z_Distance, entity.getY(), entity.getZ()))) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                  .spawn(
                     _level,
                     BlockPos.containing(
                        entity.getX() + Far_Herobrine_Anger_Z_Distance,
                        world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)(entity.getX() + Far_Herobrine_Anger_Z_Distance), (int)entity.getZ()) + 1,
                        entity.getZ()
                     ),
                     EntitySpawnReason.MOB_SUMMONED
                  );
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }
         } else {
            tempXplayerPos = entity.getX() + 8.0;
            tempYplayerPos = entity.getY();
            tempZplayerPos = entity.getZ();
            xIndex = tempXplayerPos;
            yIndex = tempYplayerPos + 10.0;
            zIndex = tempZplayerPos;

            for (int index6 = 0; index6 < 6; index6++) {
               while (yIndex > tempYplayerPos - 10.0) {
                  if (world.getBlockState(BlockPos.containing(xIndex, --yIndex, zIndex)).getBlock() == Blocks.AIR) {
                     if (world instanceof ServerLevel _level) {
                        Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
                           .spawn(_level, BlockPos.containing(xIndex, yIndex, zIndex), EntitySpawnReason.MOB_SUMMONED);
                        if (entityToSpawn != null) {
                           entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                           entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                           entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                           entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
                        }
                     }

                     spawned = 1.0;
                     break;
                  }
               }

               if (spawned == 1.0) {
                  break;
               }

               xIndex++;
            }
         }

         if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 2.0 && Mth.nextInt(RandomSource.create(), 1, 3) == 3) {
            if (Mth.nextInt(RandomSource.create(), 1, 2) == 1) {
               if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                  _entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 200, 1, false, false));
               }

               entity.push(5.0, 5.0, 5.0);
            } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 5.0 && Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
               if (world instanceof ServerLevel _level) {
                  _level.getServer()
                     .getCommands()
                     .performPrefixedCommand(
                        new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, net.minecraft.server.permissions.LevelBasedPermissionSet.OWNER, "", Component.literal(""), _level.getServer(), null)
                           .withSuppressedOutput(),
                        "weather thunder"
                     );
               }

               if (world instanceof ServerLevel _level) {
                  LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                  entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z + 10.0)));
                  _level.addFreshEntity(entityToSpawn);
               }

               if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                  _entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 500, 1, false, false));
               }

               if (world instanceof Level _level) {
                  if (!_level.isClientSide()) {
                     _level.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.soul_sand_valley.mood")),
                        SoundSource.HOSTILE,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _level.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.soul_sand_valley.mood")),
                        SoundSource.HOSTILE,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }

               if (world instanceof ServerLevel _level) {
                  LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                  entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z + 20.0)));
                  _level.addFreshEntity(entityToSpawn);
               }

               if (world instanceof ServerLevel _level) {
                  LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                  entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z - 10.0)));
                  _level.addFreshEntity(entityToSpawn);
               }

               entity.push(5.0, 5.0, 5.0);
               if (world instanceof ServerLevel _level) {
                  LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                  entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z - 15.0)));
                  _level.addFreshEntity(entityToSpawn);
               }

               if (world instanceof Level _level) {
                  if (!_level.isClientSide()) {
                     _level.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.crimson_forest.mood")),
                        SoundSource.HOSTILE,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _level.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.crimson_forest.mood")),
                        SoundSource.HOSTILE,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }

               if (world instanceof ServerLevel _level) {
                  LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                  entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z - 20.0)));
                  _level.addFreshEntity(entityToSpawn);
               }

               if (world instanceof Level _level && !_level.isClientSide()) {
                  _level.explode(null, x, y, z, 2.0F, ExplosionInteraction.MOB);
               }

               if (world instanceof ServerLevel _level) {
                  LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                  entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z - 15.0)));
                  _level.addFreshEntity(entityToSpawn);
               }

               if (world instanceof ServerLevel _level) {
                  LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                  entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z + 5.0)));
                  _level.addFreshEntity(entityToSpawn);
               }

               if (world instanceof ServerLevel _level) {
                  _level.getServer()
                     .getCommands()
                     .performPrefixedCommand(
                        new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, net.minecraft.server.permissions.LevelBasedPermissionSet.OWNER, "", Component.literal(""), _level.getServer(), null)
                           .withSuppressedOutput(),
                        "weather clear"
                     );
               }
            } else if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
               if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                  _entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 1, false, false));
               }

               if (world instanceof Level _level) {
                  if (!_level.isClientSide()) {
                     _level.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.crimson_forest.mood")),
                        SoundSource.HOSTILE,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _level.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.crimson_forest.mood")),
                        SoundSource.HOSTILE,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }
            }
         }
      }
   }
}
