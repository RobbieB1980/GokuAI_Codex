package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelAccessor;

public class HerobrineAngerDisplayTrueProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineAngerDisplayConfirmed = 1.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         if (entity instanceof Player _player) {
            _player.closeContainer();
         }
      }
   }
}
