package net.mcreator.ahorrormodtest.init;

import net.mcreator.ahorrormodtest.entity.CowTestPlayerEntity;
import net.mcreator.ahorrormodtest.entity.FarherobrineEntity;
import net.mcreator.ahorrormodtest.entity.HerobrineAttaquerEntity;
import net.mcreator.ahorrormodtest.entity.HerobrineBehindEntity;
import net.mcreator.ahorrormodtest.entity.JumpscareHerobrineEntity;
import net.mcreator.ahorrormodtest.entity.PigPlayerTestEntity;
import net.mcreator.ahorrormodtest.entity.PossessedCowEntity;
import net.mcreator.ahorrormodtest.entity.PossessedPigEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@EventBusSubscriber
public class ThenewherobrinemodModEntities {
   public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, "thenewherobrinemod");
   public static final DeferredHolder<EntityType<?>, EntityType<FarherobrineEntity>> FARHEROBRINE = register(
      "farherobrine",
      EntityType.Builder.of(FarherobrineEntity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .fireImmune()
         .ridingOffset(-0.6F)
         .sized(0.6F, 1.8F)
   );
   public static final DeferredHolder<EntityType<?>, EntityType<HerobrineAttaquerEntity>> HEROBRINE_ATTAQUER = register(
      "herobrine_attaquer",
      EntityType.Builder.of(HerobrineAttaquerEntity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .ridingOffset(-0.6F)
         .sized(0.6F, 1.8F)
   );
   public static final DeferredHolder<EntityType<?>, EntityType<PossessedCowEntity>> POSSESSED_COW = register(
      "possessed_cow",
      EntityType.Builder.of(PossessedCowEntity::new, MobCategory.AMBIENT)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .sized(0.9F, 1.4F)
   );
   public static final DeferredHolder<EntityType<?>, EntityType<JumpscareHerobrineEntity>> JUMPSCARE_HEROBRINE = register(
      "jumpscare_herobrine",
      EntityType.Builder.of(JumpscareHerobrineEntity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .fireImmune()
         .ridingOffset(-0.6F)
         .sized(0.6F, 1.8F)
   );
   public static final DeferredHolder<EntityType<?>, EntityType<CowTestPlayerEntity>> COW_TEST_PLAYER = register(
      "cow_test_player",
      EntityType.Builder.of(CowTestPlayerEntity::new, MobCategory.AMBIENT)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .sized(0.9F, 1.4F)
   );
   public static final DeferredHolder<EntityType<?>, EntityType<PossessedPigEntity>> POSSESSED_PIG = register(
      "possessed_pig",
      EntityType.Builder.of(PossessedPigEntity::new, MobCategory.AMBIENT)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .sized(0.9F, 0.9F)
   );
   public static final DeferredHolder<EntityType<?>, EntityType<PigPlayerTestEntity>> PIG_PLAYER_TEST = register(
      "pig_player_test",
      EntityType.Builder.of(PigPlayerTestEntity::new, MobCategory.AMBIENT)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .sized(0.9F, 0.9F)
   );
   public static final DeferredHolder<EntityType<?>, EntityType<HerobrineBehindEntity>> HEROBRINE_BEHIND = register(
      "herobrine_behind",
      EntityType.Builder.of(HerobrineBehindEntity::new, MobCategory.MONSTER)
         .setShouldReceiveVelocityUpdates(true)
         .setTrackingRange(64)
         .setUpdateInterval(3)
         .fireImmune()
         .ridingOffset(-0.6F)
         .sized(0.6F, 1.8F)
   );

   private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, Builder<T> entityTypeBuilder) {
      return REGISTRY.register(
         registryname,
         () -> entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("thenewherobrinemod", registryname)))
      );
   }

   @SubscribeEvent
   public static void init(RegisterSpawnPlacementsEvent event) {
      FarherobrineEntity.init(event);
      HerobrineAttaquerEntity.init(event);
      PossessedCowEntity.init(event);
      JumpscareHerobrineEntity.init(event);
      CowTestPlayerEntity.init(event);
      PossessedPigEntity.init(event);
      PigPlayerTestEntity.init(event);
      HerobrineBehindEntity.init(event);
   }

   @SubscribeEvent
   public static void registerAttributes(EntityAttributeCreationEvent event) {
      event.put((EntityType)FARHEROBRINE.get(), FarherobrineEntity.createAttributes().build());
      event.put((EntityType)HEROBRINE_ATTAQUER.get(), HerobrineAttaquerEntity.createAttributes().build());
      event.put((EntityType)POSSESSED_COW.get(), PossessedCowEntity.createAttributes().build());
      event.put((EntityType)JUMPSCARE_HEROBRINE.get(), JumpscareHerobrineEntity.createAttributes().build());
      event.put((EntityType)COW_TEST_PLAYER.get(), CowTestPlayerEntity.createAttributes().build());
      event.put((EntityType)POSSESSED_PIG.get(), PossessedPigEntity.createAttributes().build());
      event.put((EntityType)PIG_PLAYER_TEST.get(), PigPlayerTestEntity.createAttributes().build());
      event.put((EntityType)HEROBRINE_BEHIND.get(), HerobrineBehindEntity.createAttributes().build());
   }
}
