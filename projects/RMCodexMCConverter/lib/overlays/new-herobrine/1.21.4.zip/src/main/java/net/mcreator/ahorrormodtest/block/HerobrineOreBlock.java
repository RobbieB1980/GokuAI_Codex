package net.mcreator.ahorrormodtest.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;

public class HerobrineOreBlock extends Block {
   public HerobrineOreBlock(Properties properties) {
      super(properties.strength(5.0F, 10.0F).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.BASEDRUM));
   }

   public int getLightBlock(BlockState state) {
      return 15;
   }
}
