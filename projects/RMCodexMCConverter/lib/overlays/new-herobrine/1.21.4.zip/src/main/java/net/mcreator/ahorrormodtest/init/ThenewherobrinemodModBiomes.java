package net.mcreator.ahorrormodtest.init;

import com.google.common.base.Suppliers;
import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeGenerationSettings;
import net.minecraft.world.level.biome.FeatureSorter;
import net.minecraft.world.level.biome.MultiNoiseBiomeSource;
import net.minecraft.world.level.biome.Climate.Parameter;
import net.minecraft.world.level.biome.Climate.ParameterList;
import net.minecraft.world.level.biome.Climate.ParameterPoint;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.dimension.BuiltinDimensionTypes;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.SurfaceRules.RuleSource;
import net.minecraft.world.level.levelgen.SurfaceRules.SequenceRuleSource;
import net.minecraft.world.level.levelgen.placement.CaveSurface;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerAboutToStartEvent;

@EventBusSubscriber
public class ThenewherobrinemodModBiomes {
   private static net.minecraft.core.HolderGetter<Biome> biomeHolderGetter;

   @SubscribeEvent
   public static void onServerAboutToStart(ServerAboutToStartEvent event) {
      MinecraftServer server = event.getServer();
      Registry<LevelStem> levelStemTypeRegistry = server.registryAccess().lookupOrThrow(Registries.LEVEL_STEM);
      Registry<Biome> biomeRegistry = server.registryAccess().lookupOrThrow(Registries.BIOME);
      biomeHolderGetter = biomeRegistry;

      for (LevelStem levelStem : levelStemTypeRegistry.stream().toList()) {
         Holder<DimensionType> dimensionType = levelStem.type();
         if (dimensionType.is(BuiltinDimensionTypes.OVERWORLD)) {
            ChunkGenerator chunkGenerator = levelStem.generator();
            if (chunkGenerator.getBiomeSource() instanceof MultiNoiseBiomeSource noiseSource) {
               List<Pair<ParameterPoint, Holder<Biome>>> parameters = new ArrayList<>(noiseSource.parameters().values());
               addParameterPoint(
                  parameters,
                  new Pair(
                     new ParameterPoint(
                        Parameter.span(-0.5F, 0.5F),
                        Parameter.span(0.6F, 1.0001F),
                        Parameter.span(0.6F, 1.0F),
                        Parameter.span(-0.5F, 0.5F),
                        Parameter.point(0.0F),
                        Parameter.span(-1.0F, 1.0F),
                        0L
                     ),
                     biomeRegistry.getOrThrow(
                        ResourceKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("thenewherobrinemod", "herobrine_world_biome"))
                     )
                  )
               );
               addParameterPoint(
                  parameters,
                  new Pair(
                     new ParameterPoint(
                        Parameter.span(-0.5F, 0.5F),
                        Parameter.span(0.6F, 1.0001F),
                        Parameter.span(0.6F, 1.0F),
                        Parameter.span(-0.5F, 0.5F),
                        Parameter.point(1.0F),
                        Parameter.span(-1.0F, 1.0F),
                        0L
                     ),
                     biomeRegistry.getOrThrow(
                        ResourceKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("thenewherobrinemod", "herobrine_world_biome"))
                     )
                  )
               );
               chunkGenerator.biomeSource = MultiNoiseBiomeSource.createFromList(new ParameterList(parameters));
               chunkGenerator.featuresPerStep = Suppliers.memoize(
                  () -> FeatureSorter.buildFeaturesPerStep(
                     List.copyOf(chunkGenerator.biomeSource.possibleBiomes()),
                     biome -> ((BiomeGenerationSettings)chunkGenerator.generationSettingsGetter.apply(biome)).features(),
                     true
                  )
               );
            }

            // 26.2: NoiseGeneratorSettings is a final record — MCreator's mixin+interface
            // injection no longer applies (ClassCastException on world create). Biome climate
            // parameter injection above still registers herobrine_world_biome.
         }
      }
   }

   public static RuleSource adaptSurfaceRule(RuleSource currentRuleSource, Holder<DimensionType> dimensionType) {
      return dimensionType.is(BuiltinDimensionTypes.OVERWORLD) ? injectOverworldSurfaceRules(currentRuleSource) : currentRuleSource;
   }

   private static RuleSource injectOverworldSurfaceRules(RuleSource currentRuleSource) {
      if (biomeHolderGetter == null) {
         return currentRuleSource;
      }
      List<RuleSource> customSurfaceRules = new ArrayList<>();
      customSurfaceRules.add(
         preliminarySurfaceRule(
            ResourceKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath("thenewherobrinemod", "herobrine_world_biome")),
            Blocks.GRASS_BLOCK.defaultBlockState(),
            Blocks.DIRT.defaultBlockState(),
            Blocks.GRAVEL.defaultBlockState()
         )
      );
      if (currentRuleSource instanceof SequenceRuleSource sequenceRuleSource) {
         customSurfaceRules.addAll(sequenceRuleSource.sequence());
         return SurfaceRules.sequence(customSurfaceRules.toArray(RuleSource[]::new));
      } else {
         customSurfaceRules.add(currentRuleSource);
         return SurfaceRules.sequence(customSurfaceRules.toArray(RuleSource[]::new));
      }
   }

   private static RuleSource preliminarySurfaceRule(
      ResourceKey<Biome> biomeKey, BlockState groundBlock, BlockState undergroundBlock, BlockState underwaterBlock
   ) {
      return SurfaceRules.ifTrue(
         SurfaceRules.isBiome(biomeHolderGetter, biomeKey),
         SurfaceRules.ifTrue(
            SurfaceRules.abovePreliminarySurface(),
            SurfaceRules.sequence(
               new RuleSource[]{
                  SurfaceRules.ifTrue(
                     SurfaceRules.stoneDepthCheck(0, false, 0, CaveSurface.FLOOR),
                     SurfaceRules.sequence(
                        new RuleSource[]{
                           SurfaceRules.ifTrue(SurfaceRules.waterBlockCheck(-1, 0), SurfaceRules.state(groundBlock)), SurfaceRules.state(underwaterBlock)
                        }
                     )
                  ),
                  SurfaceRules.ifTrue(SurfaceRules.stoneDepthCheck(0, true, 0, CaveSurface.FLOOR), SurfaceRules.state(undergroundBlock))
               }
            )
         )
      );
   }

   private static void addParameterPoint(List<Pair<ParameterPoint, Holder<Biome>>> parameters, Pair<ParameterPoint, Holder<Biome>> point) {
      if (!parameters.contains(point)) {
         parameters.add(point);
      }
   }

   public interface ThenewherobrinemodModNoiseGeneratorSettings {
      void setthenewherobrinemodDimensionTypeReference(Holder<DimensionType> var1);
   }
}
