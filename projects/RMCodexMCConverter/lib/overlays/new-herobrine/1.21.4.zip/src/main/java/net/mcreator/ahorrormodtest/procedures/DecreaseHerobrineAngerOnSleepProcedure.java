package net.mcreator.ahorrormodtest.procedures;

import org.jetbrains.annotations.Nullable;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.level.LevelAccessor;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerWakeUpEvent;

@EventBusSubscriber
public class DecreaseHerobrineAngerOnSleepProcedure {
   @SubscribeEvent
   public static void onEntityEndSleep(PlayerWakeUpEvent event) {
      execute(event, event.getEntity().level());
   }

   public static void execute(LevelAccessor world) {
      execute(null, world);
   }

   private static void execute(@Nullable Event event, LevelAccessor world) {
      ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger -= 0.095;
      ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
      if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger < 0.0) {
         ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger = 0.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
      }
   }
}
