package net.mcreator.ahorrormodtest.client.gui;


import net.minecraft.client.input.KeyEvent;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModScreens;
import net.mcreator.ahorrormodtest.network.ConfigUIAdvancedButtonMessage;
import net.mcreator.ahorrormodtest.world.inventory.ConfigUIAdvancedMenu;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

public class ConfigUIAdvancedScreen extends AbstractContainerScreen<ConfigUIAdvancedMenu> implements ThenewherobrinemodModScreens.ScreenAccessor {
   private final Level world;
   private final int x;
   private final int y;
   private final int z;
   private final Player entity;
   private boolean menuStateUpdateActive = false;
   Button button_herobrine;
   Button button_structures;
   Button button_advanced;
   Button button_spawn_jumpscare;
   Button button_spawn_passive_herobrine;
   Button button_spawn_herobrine_attack;
   Button button_random_event;
   Button button_spawn_herobrine_behind;
   private static final Identifier texture = Identifier.parse("thenewherobrinemod:textures/screens/config_ui_advanced.png");

   public ConfigUIAdvancedScreen(ConfigUIAdvancedMenu container, Inventory inventory, Component text) {
      super(container, inventory, text, 250, 180);
      this.world = container.world;
      this.x = container.x;
      this.y = container.y;
      this.z = container.z;
      this.entity = container.entity;
   }

   @Override
   public void updateMenuState(int elementType, String name, Object elementState) {
      this.menuStateUpdateActive = true;
      this.menuStateUpdateActive = false;
   }
public void extractBackground(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
      guiGraphics.blit(
         net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, this.leftPos, this.topPos, 0.0F, 0.0F, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight
      );
   }

   public boolean keyPressed(KeyEvent event) {
      if (event.key() == 256) {
         this.minecraft.player.closeContainer();
         return true;
      } else {
         return super.keyPressed(event);
      }
   }

   protected void extractLabels(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY) {
      guiGraphics.text(this.font, Component.translatable("gui.thenewherobrinemod.config_ui_advanced.label_empty1"), 177, 21, -12829636, false);
   }

   public void init() {
      super.init();
      this.button_herobrine = Button.builder(Component.translatable("gui.thenewherobrinemod.config_ui_advanced.button_herobrine"), e -> {
         int x = this.x;
         int y = this.y;
         ClientPacketDistributor.sendToServer(new ConfigUIAdvancedButtonMessage(0, x, y, this.z), new CustomPacketPayload[0]);
         ConfigUIAdvancedButtonMessage.handleButtonAction(this.entity, 0, x, y, this.z);
      }).bounds(this.leftPos + 10, this.topPos + 6, 72, 20).build();
      this.addRenderableWidget(this.button_herobrine);
      this.button_structures = Button.builder(Component.translatable("gui.thenewherobrinemod.config_ui_advanced.button_structures"), e -> {
         int x = this.x;
         int y = this.y;
         ClientPacketDistributor.sendToServer(new ConfigUIAdvancedButtonMessage(1, x, y, this.z), new CustomPacketPayload[0]);
         ConfigUIAdvancedButtonMessage.handleButtonAction(this.entity, 1, x, y, this.z);
      }).bounds(this.leftPos + 89, this.topPos + 6, 77, 20).build();
      this.addRenderableWidget(this.button_structures);
      this.button_advanced = Button.builder(Component.translatable("gui.thenewherobrinemod.config_ui_advanced.button_advanced"), e -> {})
         .bounds(this.leftPos + 172, this.topPos + 6, 67, 20)
         .build();
      this.addRenderableWidget(this.button_advanced);
      this.button_spawn_jumpscare = Button.builder(Component.translatable("gui.thenewherobrinemod.config_ui_advanced.button_spawn_jumpscare"), e -> {
         int x = this.x;
         int y = this.y;
         ClientPacketDistributor.sendToServer(new ConfigUIAdvancedButtonMessage(3, x, y, this.z), new CustomPacketPayload[0]);
         ConfigUIAdvancedButtonMessage.handleButtonAction(this.entity, 3, x, y, this.z);
      }).bounds(this.leftPos + 10, this.topPos + 43, 103, 20).build();
      this.addRenderableWidget(this.button_spawn_jumpscare);
      this.button_spawn_passive_herobrine = Button.builder(
            Component.translatable("gui.thenewherobrinemod.config_ui_advanced.button_spawn_passive_herobrine"), e -> {
               int x = this.x;
               int y = this.y;
               ClientPacketDistributor.sendToServer(new ConfigUIAdvancedButtonMessage(4, x, y, this.z), new CustomPacketPayload[0]);
               ConfigUIAdvancedButtonMessage.handleButtonAction(this.entity, 4, x, y, this.z);
            }
         )
         .bounds(this.leftPos + 10, this.topPos + 68, 145, 20)
         .build();
      this.addRenderableWidget(this.button_spawn_passive_herobrine);
      this.button_spawn_herobrine_attack = Button.builder(
            Component.translatable("gui.thenewherobrinemod.config_ui_advanced.button_spawn_herobrine_attack"), e -> {
               int x = this.x;
               int y = this.y;
               ClientPacketDistributor.sendToServer(new ConfigUIAdvancedButtonMessage(5, x, y, this.z), new CustomPacketPayload[0]);
               ConfigUIAdvancedButtonMessage.handleButtonAction(this.entity, 5, x, y, this.z);
            }
         )
         .bounds(this.leftPos + 10, this.topPos + 93, 140, 20)
         .build();
      this.addRenderableWidget(this.button_spawn_herobrine_attack);
      this.button_random_event = Button.builder(Component.translatable("gui.thenewherobrinemod.config_ui_advanced.button_random_event"), e -> {
         int x = this.x;
         int y = this.y;
         ClientPacketDistributor.sendToServer(new ConfigUIAdvancedButtonMessage(6, x, y, this.z), new CustomPacketPayload[0]);
         ConfigUIAdvancedButtonMessage.handleButtonAction(this.entity, 6, x, y, this.z);
      }).bounds(this.leftPos + 10, this.topPos + 143, 87, 20).build();
      this.addRenderableWidget(this.button_random_event);
      this.button_spawn_herobrine_behind = Button.builder(
            Component.translatable("gui.thenewherobrinemod.config_ui_advanced.button_spawn_herobrine_behind"), e -> {
               int x = this.x;
               int y = this.y;
               ClientPacketDistributor.sendToServer(new ConfigUIAdvancedButtonMessage(7, x, y, this.z), new CustomPacketPayload[0]);
               ConfigUIAdvancedButtonMessage.handleButtonAction(this.entity, 7, x, y, this.z);
            }
         )
         .bounds(this.leftPos + 10, this.topPos + 118, 140, 20)
         .build();
      this.addRenderableWidget(this.button_spawn_herobrine_behind);
   }
}
