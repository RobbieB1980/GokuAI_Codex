package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.level.LevelAccessor;

public class AngerOverlayTextProcedure {
   public static String execute(LevelAccessor world) {
      return "Anger: " + ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger;
   }
}
