package net.mcreator.ahorrormodtest.procedures;

import java.util.ArrayList;
import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;

public class HerobrineBehindSpawnTasksProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         for (Entity entityiterator : new ArrayList<>(world.players())) {
            if (entityiterator.getDirection() == ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineBehindOrientation) {
               ThenewherobrinemodMod.queueServerWork(Mth.nextInt(RandomSource.create(), 9, 13), () -> {
                  if (!entity.level().isClientSide()) {
                     entity.discard();
                  }
               });
            }
         }
      }
   }
}
