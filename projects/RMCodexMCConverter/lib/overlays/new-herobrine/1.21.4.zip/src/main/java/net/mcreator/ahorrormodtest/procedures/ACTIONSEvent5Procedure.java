package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;

public class ACTIONSEvent5Procedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (entity instanceof Player _player) {
            _player.getFoodData().setSaturation(0.0F);
         }

         if (world instanceof ServerLevel _level) {
            LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
            entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
            entityToSpawn.setVisualOnly(true);
            _level.addFreshEntity(entityToSpawn);
         }

         if (world instanceof Level _level) {
            if (!_level.isClientSide()) {
               _level.playSound(
                  null,
                  BlockPos.containing(x, y, z),
                  (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.warped_forest.additions")),
                  SoundSource.VOICE,
                  1.0F,
                  1.0F
               );
            } else {
               _level.playLocalSound(
                  x,
                  y,
                  z,
                  (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.warped_forest.additions")),
                  SoundSource.VOICE,
                  1.0F,
                  1.0F,
                  false
               );
            }
         }

         if (!world.isClientSide() && world.getServer() != null) {
            world.getServer().getPlayerList().broadcastSystemMessage(Component.literal("<Herobrine> :)"), false);
         }

         if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 0.5) {
            entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.MOB_ATTACK)), 3.0F);
         }

         if (Mth.nextInt(RandomSource.create(), 1, 4) == 2 && ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
            EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
            ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes = 0.0;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         } else {
            ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         }
      }
   }
}
