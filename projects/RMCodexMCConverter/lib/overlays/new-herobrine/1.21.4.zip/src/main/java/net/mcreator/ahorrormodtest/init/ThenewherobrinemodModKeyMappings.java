package net.mcreator.ahorrormodtest.init;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;

@EventBusSubscriber(Dist.CLIENT)
public class ThenewherobrinemodModKeyMappings {
   public static final KeyMapping DEBUG_TICKS = new KeyMapping("key.thenewherobrinemod.debug_ticks", 75, KeyMapping.Category.MISC);

   @SubscribeEvent
   public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
      event.register(DEBUG_TICKS);
   }

   @EventBusSubscriber(Dist.CLIENT)
   public static class KeyEventListener {
      @SubscribeEvent
      public static void onClientTick(Post event) {
         if (Minecraft.getInstance().gui.screen() == null) {
         }
      }
   }
}
