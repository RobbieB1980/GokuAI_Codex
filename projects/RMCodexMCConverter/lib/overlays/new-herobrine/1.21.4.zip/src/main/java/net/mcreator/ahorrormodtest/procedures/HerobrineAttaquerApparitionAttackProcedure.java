package net.mcreator.ahorrormodtest.procedures;

import java.util.ArrayList;
import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;

public class HerobrineAttaquerApparitionAttackProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
            for (Entity entityiterator : new ArrayList<>(world.players())) {
               entityiterator.push(2.0, 0.0, 2.0);
               if (world instanceof Level _level) {
                  if (!_level.isClientSide()) {
                     _level.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.sheep.hurt")),
                        SoundSource.HOSTILE,
                        1.0F,
                        1.0F
                     );
                  } else {
                     _level.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.sheep.hurt")),
                        SoundSource.HOSTILE,
                        1.0F,
                        1.0F,
                        false
                     );
                  }
               }
            }
         }

         ThenewherobrinemodMod.queueServerWork(100, () -> {
            if (!entity.level().isClientSide()) {
               entity.discard();
            }

            if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
               for (Entity entityiteratorx : new ArrayList<>(world.players())) {
                  if (entityiteratorx instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                     _entity.addEffect(new MobEffectInstance(MobEffects.POISON, 120, 1));
                  }

                  if (!world.isClientSide() && world.getServer() != null) {
                     world.getServer().getPlayerList().broadcastSystemMessage(Component.literal("<Herobrine> ... :)"), false);
                  }
               }
            }
         });
      }
   }
}
