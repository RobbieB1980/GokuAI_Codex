package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.items.ItemHandlerHelper;

public class ACTIONEvent10Procedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (entity instanceof Player _player) {
            ItemStack _setstack = new ItemStack(Items.REDSTONE_TORCH).copy();
            _setstack.setCount(Mth.nextInt(RandomSource.create(), 1, 5));
            ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
         }

         if (entity instanceof Player _player) {
            ItemStack _setstack = new ItemStack(Blocks.PLAYER_HEAD).copy();
            _setstack.setCount(1);
            ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
         }

         ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
      }
   }
}
