package net.mcreator.ahorrormodtest.procedures;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;

public class RandomActionEventsProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         double randomEvent = 0.0;
         double randomSound = 0.0;
         double randomItem = 0.0;
         double tempTime = 0.0;
         randomEvent = Mth.nextInt(RandomSource.create(), 1, 14);
         if (randomEvent == 1.0) {
            ACTIONEvent1Procedure.execute(world, x, z);
         } else if (randomEvent == 2.0) {
            ACTIONEvent2Procedure.execute(world, x, z);
         } else if (randomEvent == 3.0) {
            ACTIONEvent3Procedure.execute(world, x, y, z, entity);
         } else if (randomEvent == 4.0) {
            ACTIONEvent4Procedure.execute(world, x, y, z, entity);
         } else if (randomEvent == 5.0) {
            ACTIONSEvent5Procedure.execute(world, x, y, z, entity);
         } else if (randomEvent == 6.0) {
            ACTIONEvent6Procedure.execute(world, x, y, z, entity);
         } else if (randomEvent == 7.0) {
            ACTIONEvent7Procedure.execute(world, x, y, z, entity);
         } else if (randomEvent == 8.0) {
            ACTIONEvent8Procedure.execute(world, entity);
         } else if (randomEvent == 9.0) {
            ACTIONEvent9Procedure.execute(world, x, y, z, entity);
         } else if (randomEvent == 10.0) {
            ACTIONEvent10Procedure.execute(world, entity);
         } else if (randomEvent == 11.0) {
            ACTIONEvent11Procedure.execute(world, x, y, z, entity);
         }

         randomEvent = Mth.nextInt(RandomSource.create(), 1, 10);
      }
   }
}
