package net.mcreator.ahorrormodtest.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ThenewherobrinemodModSounds {
   public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, "thenewherobrinemod");
   public static final DeferredHolder<SoundEvent, SoundEvent> JUMPSCARE_SOUND_1 = REGISTRY.register(
      "jumpscare_sound_1", () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("thenewherobrinemod", "jumpscare_sound_1"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> SURROUNDING_1 = REGISTRY.register(
      "surrounding_1", () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("thenewherobrinemod", "surrounding_1"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> SURROUNDING_2 = REGISTRY.register(
      "surrounding_2", () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("thenewherobrinemod", "surrounding_2"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> SURROUNDING_3 = REGISTRY.register(
      "surrounding_3", () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("thenewherobrinemod", "surrounding_3"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> DISTORTED_SURROUNDING_2 = REGISTRY.register(
      "distorted_surrounding_2",
      () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("thenewherobrinemod", "distorted_surrounding_2"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> LONG_GLITCH_SOUND_EFFECT = REGISTRY.register(
      "long_glitch_sound_effect",
      () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("thenewherobrinemod", "long_glitch_sound_effect"))
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> CONNEXION_GLITCH_SOUND_EFFECT = REGISTRY.register(
      "connexion_glitch_sound_effect",
      () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("thenewherobrinemod", "connexion_glitch_sound_effect"))
   );
}
