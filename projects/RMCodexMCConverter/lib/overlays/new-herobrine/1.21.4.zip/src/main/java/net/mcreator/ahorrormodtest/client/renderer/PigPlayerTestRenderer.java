package net.mcreator.ahorrormodtest.client.renderer;

import net.mcreator.ahorrormodtest.entity.PigPlayerTestEntity;
import net.minecraft.client.model.animal.pig.PigModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class PigPlayerTestRenderer extends MobRenderer<PigPlayerTestEntity, LivingEntityRenderState, PigModel> {
   private PigPlayerTestEntity entity = null;

   public PigPlayerTestRenderer(Context context) {
      super(context, new PigModel(context.bakeLayer(ModelLayers.PIG)), 0.5F);
   }

   public LivingEntityRenderState createRenderState() {
      return new LivingEntityRenderState();
   }

   public void extractRenderState(PigPlayerTestEntity entity, LivingEntityRenderState state, float partialTicks) {
      super.extractRenderState(entity, state, partialTicks);
      this.entity = entity;
   }

   public Identifier getTextureLocation(LivingEntityRenderState state) {
      return Identifier.parse("thenewherobrinemod:textures/entities/real_pig.png");
   }
}
