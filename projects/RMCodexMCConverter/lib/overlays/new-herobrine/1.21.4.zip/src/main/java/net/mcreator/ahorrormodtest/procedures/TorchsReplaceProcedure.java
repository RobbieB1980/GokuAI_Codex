package net.mcreator.ahorrormodtest.procedures;

import org.jetbrains.annotations.Nullable;
import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.BlockEvent.EntityPlaceEvent;

@EventBusSubscriber
public class TorchsReplaceProcedure {
   @SubscribeEvent
   public static void onBlockPlace(EntityPlaceEvent event) {
      execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ());
   }

   public static void execute(LevelAccessor world, double x, double y, double z) {
      execute(null, world, x, y, z);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
      if (world.getBlockState(BlockPos.containing(x, y, z)).getBlock() == Blocks.TORCH
         && Mth.nextInt(RandomSource.create(), 1, ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 1.0 ? 7 : 8) == 5) {
         ThenewherobrinemodMod.queueServerWork(
            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 1.0
               ? Mth.nextInt(RandomSource.create(), 1000, 1450)
               : Mth.nextInt(RandomSource.create(), 1500, 2000),
            () -> {
               if (world.getBlockState(BlockPos.containing(x, y, z)).getBlock() == Blocks.TORCH) {
                  BlockPos _bp = BlockPos.containing(x, y, z);
                  BlockState _bs = Blocks.REDSTONE_TORCH.defaultBlockState();
                  BlockState _bso = world.getBlockState(_bp);

                  for (Property<?> _propertyOld : _bso.getProperties()) {
                     Property _propertyNew = _bs.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
                     if (_propertyNew != null && _bs.getValue(_propertyNew) != null) {
                        try {
                           _bs = (BlockState)_bs.setValue(_propertyNew, _bso.getValue(_propertyOld));
                        } catch (Exception var14) {
                        }
                     }
                  }

                  world.setBlock(_bp, _bs, 3);
               }
            }
         );
      } else if (world.getBlockState(BlockPos.containing(x, y, z)).getBlock() == Blocks.WALL_TORCH && Mth.nextInt(RandomSource.create(), 1, 8) == 2) {
         ThenewherobrinemodMod.queueServerWork(
            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 1.0
               ? Mth.nextInt(RandomSource.create(), 1000, 1450)
               : Mth.nextInt(RandomSource.create(), 1500, 2000),
            () -> {
               if (world.getBlockState(BlockPos.containing(x, y, z)).getBlock() == Blocks.WALL_TORCH) {
                  BlockPos _bp = BlockPos.containing(x, y, z);
                  BlockState _bs = Blocks.REDSTONE_WALL_TORCH.defaultBlockState();
                  BlockState _bso = world.getBlockState(_bp);

                  for (Property<?> _propertyOld : _bso.getProperties()) {
                     Property _propertyNew = _bs.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
                     if (_propertyNew != null && _bs.getValue(_propertyNew) != null) {
                        try {
                           _bs = (BlockState)_bs.setValue(_propertyNew, _bso.getValue(_propertyOld));
                        } catch (Exception var14) {
                        }
                     }
                  }

                  world.setBlock(_bp, _bs, 3);
               }
            }
         );
      } else if (world.getBlockState(BlockPos.containing(x, y, z)).getBlock() == Blocks.CRAFTING_TABLE && Mth.nextInt(RandomSource.create(), 1, 15) == 4) {
         ThenewherobrinemodMod.queueServerWork(
            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 1.0
               ? Mth.nextInt(RandomSource.create(), 1000, 1450)
               : Mth.nextInt(RandomSource.create(), 1500, 2000),
            () -> {
               if (world.getBlockState(BlockPos.containing(x, y, z)).getBlock() == Blocks.CRAFTING_TABLE) {
                  if (world.getBlockState(BlockPos.containing(x, y, z + 2.0)).getBlock() == Blocks.AIR) {
                     world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                     world.setBlock(BlockPos.containing(x, y, z + 2.0), Blocks.CRAFTING_TABLE.defaultBlockState(), 3);
                  } else if (world.getBlockState(BlockPos.containing(x, y, z - 2.0)).getBlock() == Blocks.AIR) {
                     world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                     world.setBlock(BlockPos.containing(x, y, z - 2.0), Blocks.CRAFTING_TABLE.defaultBlockState(), 3);
                  } else if (world.getBlockState(BlockPos.containing(x + 2.0, y, z)).getBlock() == Blocks.AIR) {
                     world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                     world.setBlock(BlockPos.containing(x + 2.0, y, z), Blocks.CRAFTING_TABLE.defaultBlockState(), 3);
                  } else if (world.getBlockState(BlockPos.containing(x - 2.0, y, z)).getBlock() == Blocks.AIR) {
                     world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                     world.setBlock(BlockPos.containing(x - 2.0, y, z), Blocks.CRAFTING_TABLE.defaultBlockState(), 3);
                  }
               }
            }
         );
      }
   }
}
