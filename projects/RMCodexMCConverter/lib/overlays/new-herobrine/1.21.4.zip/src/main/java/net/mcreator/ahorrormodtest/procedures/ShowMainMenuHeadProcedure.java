package net.mcreator.ahorrormodtest.procedures;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

public class ShowMainMenuHeadProcedure {
   public static boolean execute() {
      boolean ShowMainMenuHead = false;
      if (Mth.nextInt(RandomSource.create(), 1, 105) == 50) {
         ShowMainMenuHead = true;
      } else {
         ShowMainMenuHead = false;
      }

      return ShowMainMenuHead;
   }
}
