package net.mcreator.ahorrormodtest.procedures;

import net.minecraft.network.chat.Component;
import net.minecraft.world.level.LevelAccessor;

public class StartEventCommandHandlerProcedure {
   public static void execute(LevelAccessor world) {
      if (!world.isClientSide() && world.getServer() != null) {
         world.getServer()
            .getPlayerList()
            .broadcastSystemMessage(
               Component.literal("A command from The New Herobrine mod. This command is reserved to developers, you cannot use it."), false
            );
      }
   }
}
