package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.level.LevelAccessor;

public class PassiveWatchingCheckboxEnabledProcedure {
   public static boolean execute(LevelAccessor world) {
      boolean IsFarHerobrineEnabled = false;
      if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
         IsFarHerobrineEnabled = true;
      } else {
         IsFarHerobrineEnabled = false;
      }

      return IsFarHerobrineEnabled;
   }
}
