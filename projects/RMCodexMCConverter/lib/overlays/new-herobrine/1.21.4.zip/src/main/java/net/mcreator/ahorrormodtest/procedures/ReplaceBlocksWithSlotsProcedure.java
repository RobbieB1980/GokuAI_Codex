package net.mcreator.ahorrormodtest.procedures;

import org.jetbrains.annotations.Nullable;
import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.event.level.BlockEvent.EntityPlaceEvent;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.IItemHandlerModifiable;

@EventBusSubscriber
public class ReplaceBlocksWithSlotsProcedure {
   @SubscribeEvent
   public static void onBlockPlace(EntityPlaceEvent event) {
      execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ());
   }

   public static void execute(LevelAccessor world, double x, double y, double z) {
      execute(null, world, x, y, z);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
      if (world.getBlockState(BlockPos.containing(x, y, z)).getBlock() == Blocks.FURNACE && Mth.nextInt(RandomSource.create(), 1, 5) == 4) {
         ThenewherobrinemodMod.queueServerWork(
            Mth.nextInt(RandomSource.create(), 6000, 10000),
            () -> {
               world.setBlock(BlockPos.containing(x, y, z + 3.0), Blocks.FURNACE.defaultBlockState(), 3);
               if (world instanceof ILevelExtension _ext
                  && _ext.getCapability(/* ItemHandler.BLOCK removed */ null, BlockPos.containing(x, y, z + 3.0), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                  ItemStack _setstack = itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).copy().copy();
                  _setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 0).getCount());
                  _itemHandlerModifiable.setStackInSlot(0, _setstack);
               }

               if (world instanceof ILevelExtension _ext
                  && _ext.getCapability(/* ItemHandler.BLOCK removed */ null, BlockPos.containing(x, y, z + 3.0), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                  ItemStack _setstack = itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy().copy();
                  _setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).getCount());
                  _itemHandlerModifiable.setStackInSlot(1, _setstack);
               }

               if (world instanceof ILevelExtension _ext
                  && _ext.getCapability(/* ItemHandler.BLOCK removed */ null, BlockPos.containing(x, y, z + 3.0), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                  ItemStack _setstack = itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).copy().copy();
                  _setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).getCount());
                  _itemHandlerModifiable.setStackInSlot(2, _setstack);
               }

               if (world instanceof ILevelExtension _ext
                  && _ext.getCapability(/* ItemHandler.BLOCK removed */ null, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                  int _slotid = 0;
                  ItemStack _stk = _itemHandlerModifiable.getStackInSlot(_slotid).copy();
                  _stk.shrink(64);
                  _itemHandlerModifiable.setStackInSlot(_slotid, _stk);
               }

               if (world instanceof ILevelExtension _ext
                  && _ext.getCapability(/* ItemHandler.BLOCK removed */ null, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                  int _slotid = 1;
                  ItemStack _stk = _itemHandlerModifiable.getStackInSlot(_slotid).copy();
                  _stk.shrink(64);
                  _itemHandlerModifiable.setStackInSlot(_slotid, _stk);
               }

               if (world instanceof ILevelExtension _ext
                  && _ext.getCapability(/* ItemHandler.BLOCK removed */ null, BlockPos.containing(x, y, z), null) instanceof IItemHandlerModifiable _itemHandlerModifiable) {
                  int _slotid = 2;
                  ItemStack _stk = _itemHandlerModifiable.getStackInSlot(_slotid).copy();
                  _stk.shrink(64);
                  _itemHandlerModifiable.setStackInSlot(_slotid, _stk);
               }

               world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
            }
         );
      }
   }

   private static ItemStack itemFromBlockInventory(LevelAccessor world, BlockPos pos, int slot) {
      if (world instanceof ILevelExtension ext) {
         IItemHandler itemHandler = (IItemHandler)ext.getCapability(/* ItemHandler.BLOCK removed */ null, pos, null);
         if (itemHandler != null) {
            return itemHandler.getStackInSlot(slot);
         }
      }

      return ItemStack.EMPTY;
   }
}
