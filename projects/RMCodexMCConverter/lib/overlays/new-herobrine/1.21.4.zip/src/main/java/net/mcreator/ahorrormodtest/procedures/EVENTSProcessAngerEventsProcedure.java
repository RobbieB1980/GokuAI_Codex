package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;

public class EVENTSProcessAngerEventsProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         double Far_Herobrine_Anger_Z_Distance = 0.0;
         if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 0.0 && Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
            if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger < 2.0) {
               ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger_Action_Type = Mth.nextInt(RandomSource.create(), 1, 3);
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
               if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger_Action_Type == 1.0) {
                  if (world instanceof Level _level) {
                     if (!_level.isClientSide()) {
                        _level.playSound(
                           null,
                           BlockPos.containing(x, y, z),
                           (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                           SoundSource.HOSTILE,
                           1.0F,
                           1.0F
                        );
                     } else {
                        _level.playLocalSound(
                           x,
                           y,
                           z,
                           (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                           SoundSource.HOSTILE,
                           1.0F,
                           1.0F,
                           false
                        );
                     }
                  }
               } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger_Action_Type == 2.0) {
                  if (world instanceof ServerLevel _level) {
                     LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                     entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z + Mth.nextInt(RandomSource.create(), 4, 9))));
                     _level.addFreshEntity(entityToSpawn);
                  }
               } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger_Action_Type == 3.0) {
                  Far_Herobrine_Anger_Z_Distance = Mth.nextInt(RandomSource.create(), 15, 20);
                  if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
                     EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
                     ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_JumpscaresEnabled == 1.0) {
                     EVENTSJumpscareHerobrineProcedure.execute(world, entity);
                     ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  }
               }
            } else {
               if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger < 5.0) {
                  if (world instanceof Level _level) {
                     if (!_level.isClientSide()) {
                        _level.playSound(
                           null,
                           BlockPos.containing(x, y, z),
                           (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.splash_potion.break")),
                           SoundSource.NEUTRAL,
                           1.0F,
                           1.0F
                        );
                     } else {
                        _level.playLocalSound(
                           x,
                           y,
                           z,
                           (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.splash_potion.break")),
                           SoundSource.NEUTRAL,
                           1.0F,
                           1.0F,
                           false
                        );
                     }
                  }

                  if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                     _entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 1, false, true));
                  }
               }

               if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
                  AccelerateEventsProcedure.execute(world, x, y, z, entity);
               }
            }
         }
      }
   }
}
