package net.mcreator.ahorrormodtest.procedures;

import org.jetbrains.annotations.Nullable;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.CanPlayerSleepEvent;

@EventBusSubscriber
public class AccelerateEventsProcedure {
   @SubscribeEvent
   public static void onPlayerInBed(CanPlayerSleepEvent event) {
      execute(event, event.getEntity().level(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getEntity());
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger == 0.0) {
            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Speed = Mth.nextInt(RandomSource.create(), 1, 1);
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger < 3.0) {
            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Speed = Mth.nextInt(RandomSource.create(), 1, 1);
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         } else {
            if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
               _entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 2, false, false));
            }

            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Speed = Mth.nextInt(RandomSource.create(), 1, 2);
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            if (world instanceof ServerLevel _level) {
               LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
               entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
               entityToSpawn.setVisualOnly(true);
               _level.addFreshEntity(entityToSpawn);
            }
         }
      }
   }
}
