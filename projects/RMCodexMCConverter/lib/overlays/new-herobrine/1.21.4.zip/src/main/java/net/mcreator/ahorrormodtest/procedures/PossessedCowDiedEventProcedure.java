package net.mcreator.ahorrormodtest.procedures;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;

public class PossessedCowDiedEventProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z) {
      if (Mth.nextDouble(RandomSource.create(), 1.0, 6.0) == 3.0 && world instanceof Level _level) {
         if (!_level.isClientSide()) {
            _level.playSound(
               null,
               BlockPos.containing(x, y, z),
               (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.nether_wastes.additions")),
               SoundSource.PLAYERS,
               2.0F,
               1.0F
            );
         } else {
            _level.playLocalSound(
               x,
               y,
               z,
               (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.nether_wastes.additions")),
               SoundSource.PLAYERS,
               2.0F,
               1.0F,
               false
            );
         }
      }
   }
}
