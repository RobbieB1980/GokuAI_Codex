package net.mcreator.ahorrormodtest.item;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item.Properties;

public class BasicHerobrinePickaxeItem extends Item {
   private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(
      BlockTags.INCORRECT_FOR_NETHERITE_TOOL,
      10000,
      15.0F,
      0.0F,
      8,
      TagKey.create(Registries.ITEM, Identifier.parse("thenewherobrinemod:basic_herobrine_pickaxe_repair_items"))
   );

   public BasicHerobrinePickaxeItem(Properties properties) {
      super(properties.pickaxe(TOOL_MATERIAL, 4.0F, -2.0F));
   }
}
