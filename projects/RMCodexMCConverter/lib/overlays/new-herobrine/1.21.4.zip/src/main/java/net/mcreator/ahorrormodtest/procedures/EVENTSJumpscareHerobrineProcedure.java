package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModEntities;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap.Types;

public class EVENTSJumpscareHerobrineProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         if (entity.getDirection() == Direction.NORTH) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.JUMPSCARE_HEROBRINE.get())
                  .spawn(
                     _level,
                     BlockPos.containing(
                        entity.getX(),
                        world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)entity.getX(), (int)(entity.getZ() - 2.0)) + 1,
                        entity.getZ() - 2.0
                     ),
                     EntitySpawnReason.MOB_SUMMONED
                  );
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }
         } else if (entity.getDirection() == Direction.SOUTH) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.JUMPSCARE_HEROBRINE.get())
                  .spawn(
                     _level,
                     BlockPos.containing(
                        entity.getX(),
                        world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)entity.getX(), (int)(entity.getZ() + 2.0)) + 1,
                        entity.getZ() + 2.0
                     ),
                     EntitySpawnReason.MOB_SUMMONED
                  );
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }
         } else if (entity.getDirection() == Direction.WEST) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.JUMPSCARE_HEROBRINE.get())
                  .spawn(
                     _level,
                     BlockPos.containing(
                        entity.getX() - 2.0,
                        world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)(entity.getX() - 2.0), (int)entity.getZ()) + 1,
                        entity.getZ()
                     ),
                     EntitySpawnReason.MOB_SUMMONED
                  );
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }
         } else if (world instanceof ServerLevel _level) {
            Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.JUMPSCARE_HEROBRINE.get())
               .spawn(
                  _level,
                  BlockPos.containing(
                     entity.getX() + 2.0, world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)(entity.getX() + 2.0), (int)entity.getZ()) + 1, entity.getZ()
                  ),
                  EntitySpawnReason.MOB_SUMMONED
               );
            if (entityToSpawn != null) {
               entityToSpawn.setYRot(entity.getYRot() - 180.0F);
               entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
               entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
               entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
            }
         }

         if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 1.0) {
            entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.GENERIC)), 1.0F);
         }
      }
   }
}
