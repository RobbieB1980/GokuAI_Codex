package net.mcreator.ahorrormodtest.procedures;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;

public class ShowCreativeOnlyProcedure {
   public static boolean execute(Entity entity) {
      if (entity == null) {
         return false;
      }

      boolean ShowOnly = false;
      if (getEntityGameType(entity) == GameType.CREATIVE) {
         ShowOnly = false;
      } else {
         ShowOnly = true;
      }

      return ShowOnly;
   }

   private static GameType getEntityGameType(Entity entity) {
      if (entity instanceof ServerPlayer serverPlayer) {
         return serverPlayer.gameMode.getGameModeForPlayer();
      } else {
         if (entity instanceof Player player && player.level().isClientSide()) {
            PlayerInfo playerInfo = Minecraft.getInstance().getConnection().getPlayerInfo(player.getGameProfile().id());
            if (playerInfo != null) {
               return playerInfo.getGameMode();
            }
         }

         return null;
      }
   }
}
