package net.mcreator.ahorrormodtest.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@EventBusSubscriber
public class ThenewherobrinemodModTabs {
   public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "thenewherobrinemod");
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> HEROBRINE_MOD = REGISTRY.register(
      "herobrine_mod",
      () -> CreativeModeTab.builder()
         .title(Component.translatable("item_group.thenewherobrinemod.herobrine_mod"))
         .icon(() -> new ItemStack(Blocks.PLAYER_HEAD))
         .displayItems((parameters, tabData) -> {
            tabData.accept((ItemLike)ThenewherobrinemodModItems.HEROBRINE_ORE_GEM.get());
            tabData.accept((ItemLike)ThenewherobrinemodModItems.HEROBRINE_SWORD.get());
            tabData.accept((ItemLike)ThenewherobrinemodModItems.BASIC_HEROBRINE_PICKAXE.get());
            tabData.accept((ItemLike)ThenewherobrinemodModItems.FARHEROBRINE_SPAWN_EGG.get());
            tabData.accept((ItemLike)ThenewherobrinemodModItems.HEROBRINE_ATTAQUER_SPAWN_EGG.get());
            tabData.accept((ItemLike)ThenewherobrinemodModItems.JUMPSCARE_HEROBRINE_SPAWN_EGG.get());
            tabData.accept((ItemLike)ThenewherobrinemodModItems.POSSESSED_COW_SPAWN_EGG.get());
            tabData.accept((ItemLike)ThenewherobrinemodModItems.POSSESSED_PIG_SPAWN_EGG.get());
            tabData.accept((ItemLike)ThenewherobrinemodModItems.PIG_PLAYER_TEST_SPAWN_EGG.get());
            tabData.accept((ItemLike)ThenewherobrinemodModItems.COW_TEST_PLAYER_SPAWN_EGG.get());
         })
         .build()
   );

   @SubscribeEvent
   public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
      if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
         tabData.accept((ItemLike)ThenewherobrinemodModItems.HEROBRINE_BEHIND_SPAWN_EGG.get());
      }
   }
}
