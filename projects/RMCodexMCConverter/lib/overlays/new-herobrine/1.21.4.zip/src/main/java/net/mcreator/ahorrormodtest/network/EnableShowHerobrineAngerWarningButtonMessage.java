package net.mcreator.ahorrormodtest.network;

import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.mcreator.ahorrormodtest.procedures.HerobrineAngerDisplayFalseProcedure;
import net.mcreator.ahorrormodtest.procedures.HerobrineAngerDisplayTrueProcedure;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;

@EventBusSubscriber
public record EnableShowHerobrineAngerWarningButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {
   public static final Type<EnableShowHerobrineAngerWarningButtonMessage> TYPE = new Type(
      Identifier.fromNamespaceAndPath("thenewherobrinemod", "enable_show_herobrine_anger_warning_buttons")
   );
   public static final StreamCodec<RegistryFriendlyByteBuf, EnableShowHerobrineAngerWarningButtonMessage> STREAM_CODEC = StreamCodec.of((buffer, message) -> {
      buffer.writeInt(message.buttonID);
      buffer.writeInt(message.x);
      buffer.writeInt(message.y);
      buffer.writeInt(message.z);
   }, buffer -> new EnableShowHerobrineAngerWarningButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));

   public Type<EnableShowHerobrineAngerWarningButtonMessage> type() {
      return TYPE;
   }

   public static void handleData(EnableShowHerobrineAngerWarningButtonMessage message, IPayloadContext context) {
      if (context.flow() == PacketFlow.SERVERBOUND) {
         context.enqueueWork(() -> handleButtonAction(context.player(), message.buttonID, message.x, message.y, message.z)).exceptionally(e -> {
            context.connection().disconnect(Component.literal(e.getMessage()));
            return null;
         });
      }
   }

   public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
      Level world = entity.level();
      if (world.hasChunkAt(new BlockPos(x, y, z))) {
         if (buttonID == 0) {
            HerobrineAngerDisplayTrueProcedure.execute(world, entity);
         }

         if (buttonID == 1) {
            HerobrineAngerDisplayFalseProcedure.execute(world, x, y, z, entity);
         }
      }
   }

   @SubscribeEvent
   public static void registerMessage(FMLCommonSetupEvent event) {
      ThenewherobrinemodMod.addNetworkMessage(TYPE, STREAM_CODEC, EnableShowHerobrineAngerWarningButtonMessage::handleData);
   }
}
