package net.mcreator.ahorrormodtest.item;


import net.minecraft.world.item.Item;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item.Properties;

public class HerobrineSwordItem extends Item {
   private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(
      BlockTags.INCORRECT_FOR_NETHERITE_TOOL,
      12000,
      15.0F,
      0.0F,
      9,
      TagKey.create(Registries.ITEM, Identifier.parse("thenewherobrinemod:herobrine_sword_repair_items"))
   );

   public HerobrineSwordItem(Properties properties) {
      super(properties.sword(TOOL_MATERIAL, 4.5F, 2.0F));
   }
}
