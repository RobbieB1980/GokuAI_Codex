package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModEntities;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap.Types;

public class BlockCasseEventsProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (Mth.nextDouble(RandomSource.create(), 1.0, 30.0) == 21.0) {
            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Speed = Mth.nextDouble(RandomSource.create(), 2.0, 3.0);
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            if (world instanceof Level _level) {
               if (!_level.isClientSide()) {
                  _level.playSound(
                     null,
                     BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()),
                     (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.crimson_forest.additions")),
                     SoundSource.BLOCKS,
                     1.0F,
                     1.0F
                  );
               } else {
                  _level.playLocalSound(
                     entity.getX(),
                     entity.getY(),
                     entity.getZ(),
                     (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.crimson_forest.additions")),
                     SoundSource.BLOCKS,
                     1.0F,
                     1.0F,
                     false
                  );
               }
            }
         }

         if (Mth.nextDouble(RandomSource.create(), 1.0, 30.0) == 19.0 && world instanceof ServerLevel _level) {
            Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get())
               .spawn(
                  _level,
                  BlockPos.containing(
                     entity.getX(), world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)entity.getX(), (int)(entity.getZ() + 20.0)) + 1, entity.getZ() + 20.0
                  ),
                  EntitySpawnReason.MOB_SUMMONED
               );
            if (entityToSpawn != null) {
               entityToSpawn.setYRot(entity.getYRot() - 180.0F);
               entityToSpawn.setYBodyRot(entity.getYRot() - 180.0F);
               entityToSpawn.setYHeadRot(entity.getYRot() - 180.0F);
               entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
            }
         }
      }
   }
}
