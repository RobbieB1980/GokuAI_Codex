package net.mcreator.ahorrormodtest.init;

import net.mcreator.ahorrormodtest.client.gui.ConfigUIAdvancedScreen;
import net.mcreator.ahorrormodtest.client.gui.ConfigUIHerobrineScreen;
import net.mcreator.ahorrormodtest.client.gui.ConfigUIStructuresScreen;
import net.mcreator.ahorrormodtest.client.gui.EnableShowHerobrineAngerWarningScreen;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

@EventBusSubscriber(Dist.CLIENT)
public class ThenewherobrinemodModScreens {
   @SubscribeEvent
   public static void clientLoad(RegisterMenuScreensEvent event) {
      event.register((MenuType)ThenewherobrinemodModMenus.CONFIG_UI_HEROBRINE.get(), ConfigUIHerobrineScreen::new);
      event.register((MenuType)ThenewherobrinemodModMenus.CONFIG_UI_STRUCTURES.get(), ConfigUIStructuresScreen::new);
      event.register((MenuType)ThenewherobrinemodModMenus.CONFIG_UI_ADVANCED.get(), ConfigUIAdvancedScreen::new);
      event.register((MenuType)ThenewherobrinemodModMenus.ENABLE_SHOW_HEROBRINE_ANGER_WARNING.get(), EnableShowHerobrineAngerWarningScreen::new);
   }

   public interface ScreenAccessor {
      void updateMenuState(int var1, String var2, Object var3);
   }
}
