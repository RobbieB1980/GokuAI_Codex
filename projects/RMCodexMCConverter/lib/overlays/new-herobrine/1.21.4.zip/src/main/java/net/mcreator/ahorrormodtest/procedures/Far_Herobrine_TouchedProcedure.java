package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public class Far_Herobrine_TouchedProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (world instanceof ServerLevel _level) {
            _level.getServer()
               .getCommands()
               .performPrefixedCommand(
                  new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, net.minecraft.server.permissions.LevelBasedPermissionSet.OWNER, "", Component.literal(""), _level.getServer(), null)
                     .withSuppressedOutput(),
                  "weather thunder"
               );
         }

         if (world instanceof ServerLevel _level) {
            LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
            entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
            _level.addFreshEntity(entityToSpawn);
         }

         if (world instanceof Level _level) {
            if (!_level.isClientSide()) {
               _level.playSound(
                  null,
                  BlockPos.containing(x, y, z),
                  (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                  SoundSource.RECORDS,
                  5.0F,
                  1.0F
               );
            } else {
               _level.playLocalSound(
                  x, y, z, (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")), SoundSource.RECORDS, 5.0F, 1.0F, false
               );
            }
         }

         if (!entity.level().isClientSide()) {
            entity.discard();
         }

         ThenewherobrinemodMod.queueServerWork(
            20,
            () -> {
               if (world instanceof Level _levelx) {
                  if (!_levelx.isClientSide()) {
                     _levelx.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.nether_wastes.additions")),
                        SoundSource.HOSTILE,
                        15.0F,
                        1.0F
                     );
                  } else {
                     _levelx.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.nether_wastes.additions")),
                        SoundSource.HOSTILE,
                        15.0F,
                        1.0F,
                        false
                     );
                  }
               }
            }
         );
         ThenewherobrinemodMod.queueServerWork(
            50,
            () -> {
               if (world instanceof Level _levelx) {
                  if (!_levelx.isClientSide()) {
                     _levelx.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                        SoundSource.MASTER,
                        15.0F,
                        1.0F
                     );
                  } else {
                     _levelx.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                        SoundSource.MASTER,
                        15.0F,
                        1.0F,
                        false
                     );
                  }
               }
            }
         );
         ThenewherobrinemodMod.queueServerWork(
            100,
            () -> {
               if (world instanceof Level _levelx) {
                  if (!_levelx.isClientSide()) {
                     _levelx.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                        SoundSource.NEUTRAL,
                        15.0F,
                        1.0F
                     );
                  } else {
                     _levelx.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                        SoundSource.NEUTRAL,
                        15.0F,
                        1.0F,
                        false
                     );
                  }
               }
            }
         );
         ThenewherobrinemodMod.queueServerWork(
            200,
            () -> {
               if (world instanceof Level _levelx) {
                  if (!_levelx.isClientSide()) {
                     _levelx.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.warped_forest.mood")),
                        SoundSource.NEUTRAL,
                        15.0F,
                        1.0F
                     );
                  } else {
                     _levelx.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.warped_forest.mood")),
                        SoundSource.NEUTRAL,
                        15.0F,
                        1.0F,
                        false
                     );
                  }
               }
            }
         );
         ThenewherobrinemodMod.queueServerWork(
            250,
            () -> {
               if (world instanceof ServerLevel _levelxx) {
                  _levelxx.getServer()
                     .getCommands()
                     .performPrefixedCommand(
                        new CommandSourceStack(
                              CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _levelxx, net.minecraft.server.permissions.LevelBasedPermissionSet.OWNER, "", Component.literal(""), _levelxx.getServer(), null
                           )
                           .withSuppressedOutput(),
                        "weather clear"
                     );
               }

               if (world instanceof Level _levelx) {
                  if (!_levelx.isClientSide()) {
                     _levelx.playSound(
                        null,
                        BlockPos.containing(x, y, z),
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                        SoundSource.BLOCKS,
                        15.0F,
                        1.0F
                     );
                  } else {
                     _levelx.playLocalSound(
                        x,
                        y,
                        z,
                        (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                        SoundSource.BLOCKS,
                        15.0F,
                        1.0F,
                        false
                     );
                  }
               }
            }
         );
      }
   }
}
