package net.mcreator.ahorrormodtest.network;

import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.resources.Identifier;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;

@EventBusSubscriber
public record DEBUGTicksMessage(int eventType, int pressedms) implements CustomPacketPayload {
   public static final Type<DEBUGTicksMessage> TYPE = new Type(Identifier.fromNamespaceAndPath("thenewherobrinemod", "key_debug_ticks"));
   public static final StreamCodec<RegistryFriendlyByteBuf, DEBUGTicksMessage> STREAM_CODEC = StreamCodec.of((buffer, message) -> {
      buffer.writeInt(message.eventType);
      buffer.writeInt(message.pressedms);
   }, buffer -> new DEBUGTicksMessage(buffer.readInt(), buffer.readInt()));

   public Type<DEBUGTicksMessage> type() {
      return TYPE;
   }

   public static void handleData(DEBUGTicksMessage message, IPayloadContext context) {
      if (context.flow() == PacketFlow.SERVERBOUND) {
         context.enqueueWork(() -> {}).exceptionally(e -> {
            context.connection().disconnect(Component.literal(e.getMessage()));
            return null;
         });
      }
   }

   @SubscribeEvent
   public static void registerMessage(FMLCommonSetupEvent event) {
      ThenewherobrinemodMod.addNetworkMessage(TYPE, STREAM_CODEC, DEBUGTicksMessage::handleData);
   }
}
