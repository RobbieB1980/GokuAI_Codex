package net.mcreator.ahorrormodtest.client.gui;


import net.minecraft.client.input.KeyEvent;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModScreens;
import net.mcreator.ahorrormodtest.network.EnableShowHerobrineAngerWarningButtonMessage;
import net.mcreator.ahorrormodtest.world.inventory.EnableShowHerobrineAngerWarningMenu;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

public class EnableShowHerobrineAngerWarningScreen
   extends AbstractContainerScreen<EnableShowHerobrineAngerWarningMenu>
   implements ThenewherobrinemodModScreens.ScreenAccessor {
   private final Level world;
   private final int x;
   private final int y;
   private final int z;
   private final Player entity;
   private boolean menuStateUpdateActive = false;
   Button button_i_dont_care;
   Button button_no_cancel;
   private static final Identifier texture = Identifier.parse("thenewherobrinemod:textures/screens/enable_show_herobrine_anger_warning.png");

   public EnableShowHerobrineAngerWarningScreen(EnableShowHerobrineAngerWarningMenu container, Inventory inventory, Component text) {
      super(container, inventory, text, 240, 150);
      this.world = container.world;
      this.x = container.x;
      this.y = container.y;
      this.z = container.z;
      this.entity = container.entity;
   }

   @Override
   public void updateMenuState(int elementType, String name, Object elementState) {
      this.menuStateUpdateActive = true;
      this.menuStateUpdateActive = false;
   }
public void extractBackground(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
      guiGraphics.blit(
         net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, this.leftPos, this.topPos, 0.0F, 0.0F, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight
      );
   }

   public boolean keyPressed(KeyEvent event) {
      if (event.key() == 256) {
         this.minecraft.player.closeContainer();
         return true;
      } else {
         return super.keyPressed(event);
      }
   }

   protected void extractLabels(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY) {
      guiGraphics.text(
         this.font, Component.translatable("gui.thenewherobrinemod.enable_show_herobrine_anger_warning.label_warnin"), 102, 6, -52429, false
      );
      guiGraphics.text(
         this.font,
         Component.translatable("gui.thenewherobrinemod.enable_show_herobrine_anger_warning.label_u_r_enablin_dangerous_feachur"),
         37,
         36,
         -12829636,
         false
      );
      guiGraphics.text(
         this.font,
         Component.translatable("gui.thenewherobrinemod.enable_show_herobrine_anger_warning.label_it_can_ruin_teh_events_suprize"),
         37,
         51,
         -12829636,
         false
      );
      guiGraphics.text(
         this.font,
         Component.translatable("gui.thenewherobrinemod.enable_show_herobrine_anger_warning.label_an_mak_herobrine_predictable"),
         37,
         66,
         -12829636,
         false
      );
      guiGraphics.text(
         this.font, Component.translatable("gui.thenewherobrinemod.enable_show_herobrine_anger_warning.label_do_u_wants_2_continue"), 62, 98, -39424, false
      );
   }

   public void init() {
      super.init();
      this.button_i_dont_care = Button.builder(Component.translatable("gui.thenewherobrinemod.enable_show_herobrine_anger_warning.button_i_dont_care"), e -> {
         int x = this.x;
         int y = this.y;
         ClientPacketDistributor.sendToServer(new EnableShowHerobrineAngerWarningButtonMessage(0, x, y, this.z), new CustomPacketPayload[0]);
         EnableShowHerobrineAngerWarningButtonMessage.handleButtonAction(this.entity, 0, x, y, this.z);
      }).bounds(this.leftPos + 37, this.topPos + 123, 87, 20).build();
      this.addRenderableWidget(this.button_i_dont_care);
      this.button_no_cancel = Button.builder(Component.translatable("gui.thenewherobrinemod.enable_show_herobrine_anger_warning.button_no_cancel"), e -> {
         int x = this.x;
         int y = this.y;
         ClientPacketDistributor.sendToServer(new EnableShowHerobrineAngerWarningButtonMessage(1, x, y, this.z), new CustomPacketPayload[0]);
         EnableShowHerobrineAngerWarningButtonMessage.handleButtonAction(this.entity, 1, x, y, this.z);
      }).bounds(this.leftPos + 130, this.topPos + 123, 72, 20).build();
      this.addRenderableWidget(this.button_no_cancel);
   }
}
