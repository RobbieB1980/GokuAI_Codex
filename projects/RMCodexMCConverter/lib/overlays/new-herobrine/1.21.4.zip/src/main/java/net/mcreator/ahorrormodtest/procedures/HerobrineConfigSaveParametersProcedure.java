package net.mcreator.ahorrormodtest.procedures;

import io.netty.buffer.Unpooled;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModMenus;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.mcreator.ahorrormodtest.world.inventory.ConfigUIHerobrineMenu;
import net.mcreator.ahorrormodtest.world.inventory.ConfigUIStructuresMenu;
import net.mcreator.ahorrormodtest.world.inventory.EnableShowHerobrineAngerWarningMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.LevelAccessor;

public class HerobrineConfigSaveParametersProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (entity instanceof Player _plr0 && _plr0.containerMenu instanceof ConfigUIHerobrineMenu) {
            if (entity instanceof Player _entity1
               && _entity1.containerMenu instanceof ThenewherobrinemodModMenus.MenuAccessor _menu1
               && _menu1.getMenuState(1, "JumpscaresEnabledCheckBox", false)) {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_JumpscaresEnabled = 1.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            } else {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_JumpscaresEnabled = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            }

            if (entity instanceof Player _entity2
               && _entity2.containerMenu instanceof ThenewherobrinemodModMenus.MenuAccessor _menu2
               && _menu2.getMenuState(1, "FarHerobrineEnabledCheckBox", false)) {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled = 1.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            } else {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            }

            if (entity instanceof Player _entity3
               && _entity3.containerMenu instanceof ThenewherobrinemodModMenus.MenuAccessor _menu3
               && _menu3.getMenuState(1, "HerobrineAttackEnabledCheckBox", false)) {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineAttackEnabled = 1.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            } else {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineAttackEnabled = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            }

            if (entity instanceof Player _entity4
               && _entity4.containerMenu instanceof ThenewherobrinemodModMenus.MenuAccessor _menu4
               && _menu4.getMenuState(1, "SpawnBehindCheckBox", false)) {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineBehindEnabled = 1.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            } else {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineBehindEnabled = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            }

            if (entity instanceof Player _entity5
               && _entity5.containerMenu instanceof ThenewherobrinemodModMenus.MenuAccessor _menu5
               && _menu5.getMenuState(1, "HerobrineAngerDisplayEnabledCheckBox", false)
               && ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineAngerDisplayConfirmed == 0.0) {
               if (ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineAngerDisplayConfirmed == 0.0 && entity instanceof ServerPlayer _ent) {
                  final BlockPos _bpos = BlockPos.containing(x, y, z);
                  _ent.openMenu(new MenuProvider() {
                     public Component getDisplayName() {
                        return Component.literal("EnableShowHerobrineAngerWarning");
                     }

                     public boolean shouldTriggerClientSideContainerClosingOnOpen() {
                        return false;
                     }

                     public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
                        return new EnableShowHerobrineAngerWarningMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
                     }
                  }, _bpos);
               }
            } else if (!(
                  entity instanceof Player _entity7
                     && _entity7.containerMenu instanceof ThenewherobrinemodModMenus.MenuAccessor _menu7
                     && _menu7.getMenuState(1, "HerobrineAngerDisplayEnabledCheckBox", false)
               )
               && ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineAngerDisplayConfirmed == 1.0) {
               ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineAngerDisplayConfirmed = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            }
         } else if (entity instanceof Player _plr8 && _plr8.containerMenu instanceof ConfigUIStructuresMenu) {
            if (entity instanceof Player _entity9
               && _entity9.containerMenu instanceof ThenewherobrinemodModMenus.MenuAccessor _menu9
               && _menu9.getMenuState(1, "IsCrucifixEnabledCheckbox", false)) {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_CrucifixSpawn = 1.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            } else {
               ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_CrucifixSpawn = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            }
         }
      }
   }
}
