package net.mcreator.ahorrormodtest.init;

import java.util.function.Function;
import net.mcreator.ahorrormodtest.item.BasicHerobrinePickaxeItem;
import net.mcreator.ahorrormodtest.item.HerobrineOreGemItem;
import net.mcreator.ahorrormodtest.item.HerobrineSwordItem;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Items;

public class ThenewherobrinemodModItems {
   public static final Items REGISTRY = DeferredRegister.createItems("thenewherobrinemod");
   public static final DeferredItem<Item> FARHEROBRINE_SPAWN_EGG = register(
      "farherobrine_spawn_egg", properties -> new SpawnEggItem(properties.component(net.minecraft.core.component.DataComponents.ENTITY_DATA, net.minecraft.world.item.component.TypedEntityData.of((EntityType)ThenewherobrinemodModEntities.FARHEROBRINE.get(), new net.minecraft.nbt.CompoundTag())))
   );
   public static final DeferredItem<Item> HEROBRINE_ATTAQUER_SPAWN_EGG = register(
      "herobrine_attaquer_spawn_egg", properties -> new SpawnEggItem(properties.component(net.minecraft.core.component.DataComponents.ENTITY_DATA, net.minecraft.world.item.component.TypedEntityData.of((EntityType)ThenewherobrinemodModEntities.HEROBRINE_ATTAQUER.get(), new net.minecraft.nbt.CompoundTag())))
   );
   public static final DeferredItem<Item> POSSESSED_COW_SPAWN_EGG = register(
      "possessed_cow_spawn_egg", properties -> new SpawnEggItem(properties.component(net.minecraft.core.component.DataComponents.ENTITY_DATA, net.minecraft.world.item.component.TypedEntityData.of((EntityType)ThenewherobrinemodModEntities.POSSESSED_COW.get(), new net.minecraft.nbt.CompoundTag())))
   );
   public static final DeferredItem<Item> HEROBRINE_ORE_GEM = register("herobrine_ore_gem", HerobrineOreGemItem::new);
   public static final DeferredItem<Item> HEROBRINE_ORE = block(ThenewherobrinemodModBlocks.HEROBRINE_ORE);
   public static final DeferredItem<Item> BASIC_HEROBRINE_PICKAXE = register("basic_herobrine_pickaxe", BasicHerobrinePickaxeItem::new);
   public static final DeferredItem<Item> HEROBRINE_SWORD = register("herobrine_sword", HerobrineSwordItem::new);
   public static final DeferredItem<Item> JUMPSCARE_HEROBRINE_SPAWN_EGG = register(
      "jumpscare_herobrine_spawn_egg", properties -> new SpawnEggItem(properties.component(net.minecraft.core.component.DataComponents.ENTITY_DATA, net.minecraft.world.item.component.TypedEntityData.of((EntityType)ThenewherobrinemodModEntities.JUMPSCARE_HEROBRINE.get(), new net.minecraft.nbt.CompoundTag())))
   );
   public static final DeferredItem<Item> COW_TEST_PLAYER_SPAWN_EGG = register(
      "cow_test_player_spawn_egg", properties -> new SpawnEggItem(properties.component(net.minecraft.core.component.DataComponents.ENTITY_DATA, net.minecraft.world.item.component.TypedEntityData.of((EntityType)ThenewherobrinemodModEntities.COW_TEST_PLAYER.get(), new net.minecraft.nbt.CompoundTag())))
   );
   public static final DeferredItem<Item> POSSESSED_PIG_SPAWN_EGG = register(
      "possessed_pig_spawn_egg", properties -> new SpawnEggItem(properties.component(net.minecraft.core.component.DataComponents.ENTITY_DATA, net.minecraft.world.item.component.TypedEntityData.of((EntityType)ThenewherobrinemodModEntities.POSSESSED_PIG.get(), new net.minecraft.nbt.CompoundTag())))
   );
   public static final DeferredItem<Item> PIG_PLAYER_TEST_SPAWN_EGG = register(
      "pig_player_test_spawn_egg", properties -> new SpawnEggItem(properties.component(net.minecraft.core.component.DataComponents.ENTITY_DATA, net.minecraft.world.item.component.TypedEntityData.of((EntityType)ThenewherobrinemodModEntities.PIG_PLAYER_TEST.get(), new net.minecraft.nbt.CompoundTag())))
   );
   public static final DeferredItem<Item> HEROBRINE_BEHIND_SPAWN_EGG = register(
      "herobrine_behind_spawn_egg", properties -> new SpawnEggItem(properties.component(net.minecraft.core.component.DataComponents.ENTITY_DATA, net.minecraft.world.item.component.TypedEntityData.of((EntityType)ThenewherobrinemodModEntities.HEROBRINE_BEHIND.get(), new net.minecraft.nbt.CompoundTag())))
   );

   private static <I extends Item> DeferredItem<I> register(String name, Function<Properties, ? extends I> supplier) {
      return REGISTRY.registerItem(name, supplier);
   }

   private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
      return block(block, new Properties());
   }

   private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Properties properties) {
      return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem((Block)block.get(), prop), () -> properties);
   }
}
