package net.mcreator.ahorrormodtest.world.inventory;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModMenus;
import net.mcreator.ahorrormodtest.procedures.HerobrineConfigSaveParametersProcedure;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Post;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;

@EventBusSubscriber
public class ConfigUIHerobrineMenu extends AbstractContainerMenu implements ThenewherobrinemodModMenus.MenuAccessor {
   public final Map<String, Object> menuState = new HashMap<String, Object>() {
      public Object put(String key, Object value) {
         return !this.containsKey(key) && this.size() >= 12 ? null : super.put(key, value);
      }
   };
   public final Level world;
   public final Player entity;
   public int x;
   public int y;
   public int z;
   private ContainerLevelAccess access = ContainerLevelAccess.NULL;
   private IItemHandler internal;
   private final Map<Integer, Slot> customSlots = new HashMap<>();
   private boolean bound = false;
   private Supplier<Boolean> boundItemMatcher = null;
   private Entity boundEntity = null;
   private BlockEntity boundBlockEntity = null;

   public ConfigUIHerobrineMenu(int id, Inventory inv, FriendlyByteBuf extraData) {
      super((MenuType)ThenewherobrinemodModMenus.CONFIG_UI_HEROBRINE.get(), id);
      this.entity = inv.player;
      this.world = inv.player.level();
      this.internal = new ItemStackHandler(0);
      BlockPos pos = null;
      if (extraData != null) {
         pos = extraData.readBlockPos();
         this.x = pos.getX();
         this.y = pos.getY();
         this.z = pos.getZ();
         this.access = ContainerLevelAccess.create(this.world, pos);
      }
   }

   public boolean stillValid(Player player) {
      if (this.bound) {
         if (this.boundItemMatcher != null) {
            return this.boundItemMatcher.get();
         }

         if (this.boundBlockEntity != null) {
            return AbstractContainerMenu.stillValid(this.access, player, this.boundBlockEntity.getBlockState().getBlock());
         }

         if (this.boundEntity != null) {
            return this.boundEntity.isAlive();
         }
      }

      return true;
   }

   public ItemStack quickMoveStack(Player playerIn, int index) {
      return ItemStack.EMPTY;
   }

   @Override
   public Map<Integer, Slot> getSlots() {
      return Collections.unmodifiableMap(this.customSlots);
   }

   @Override
   public Map<String, Object> getMenuState() {
      return this.menuState;
   }

   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      Player entity = event.getEntity();
      if (entity.containerMenu instanceof ConfigUIHerobrineMenu menu) {
         Level world = menu.world;
         double x = menu.x;
         double y = menu.y;
         double z = menu.z;
         HerobrineConfigSaveParametersProcedure.execute(world, x, y, z, entity);
      }
   }
}
