package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.level.LevelAccessor;

public class SpawnBehindPlayerEnabledProcedure {
   public static boolean execute(LevelAccessor world) {
      boolean SpawnBehindPlayerEnabled = false;
      if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineBehindEnabled == 1.0) {
         SpawnBehindPlayerEnabled = true;
      } else {
         SpawnBehindPlayerEnabled = false;
      }

      return SpawnBehindPlayerEnabled;
   }
}
