package net.mcreator.ahorrormodtest.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item.Properties;

public class HerobrineOreGemItem extends Item {
   public HerobrineOreGemItem(Properties properties) {
      super(properties.rarity(Rarity.UNCOMMON));
   }
}
