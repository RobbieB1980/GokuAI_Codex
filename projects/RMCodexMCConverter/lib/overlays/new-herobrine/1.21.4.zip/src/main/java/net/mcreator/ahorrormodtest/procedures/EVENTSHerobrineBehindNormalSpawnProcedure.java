package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.init.ThenewherobrinemodModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap.Types;

public class EVENTSHerobrineBehindNormalSpawnProcedure {
   public static void execute(LevelAccessor world, double x, double z, Entity entity) {
      if (entity != null) {
         if (entity.getDirection() == Direction.NORTH) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.HEROBRINE_BEHIND.get())
                  .spawn(
                     _level,
                     BlockPos.containing(x, world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)x, (int)(z + 1.0)), z + 1.0),
                     EntitySpawnReason.MOB_SUMMONED
                  );
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot());
                  entityToSpawn.setYBodyRot(entity.getYRot());
                  entityToSpawn.setYHeadRot(entity.getYRot());
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }
         } else if (entity.getDirection() == Direction.SOUTH) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.HEROBRINE_BEHIND.get())
                  .spawn(
                     _level,
                     BlockPos.containing(x, world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)x, (int)(z - 1.0)), z - 1.0),
                     EntitySpawnReason.MOB_SUMMONED
                  );
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot());
                  entityToSpawn.setYBodyRot(entity.getYRot());
                  entityToSpawn.setYHeadRot(entity.getYRot());
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }
         } else if (entity.getDirection() == Direction.WEST) {
            if (world instanceof ServerLevel _level) {
               Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.HEROBRINE_BEHIND.get())
                  .spawn(
                     _level,
                     BlockPos.containing(x + 1.0, world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)(x + 1.0), (int)z), z),
                     EntitySpawnReason.MOB_SUMMONED
                  );
               if (entityToSpawn != null) {
                  entityToSpawn.setYRot(entity.getYRot());
                  entityToSpawn.setYBodyRot(entity.getYRot());
                  entityToSpawn.setYHeadRot(entity.getYRot());
                  entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
               }
            }
         } else if (world instanceof ServerLevel _level) {
            Entity entityToSpawn = ((EntityType)ThenewherobrinemodModEntities.HEROBRINE_BEHIND.get())
               .spawn(
                  _level,
                  BlockPos.containing(x - 1.0, world.getHeight(Types.MOTION_BLOCKING_NO_LEAVES, (int)(x - 1.0), (int)z), z),
                  EntitySpawnReason.MOB_SUMMONED
               );
            if (entityToSpawn != null) {
               entityToSpawn.setYRot(entity.getYRot());
               entityToSpawn.setYBodyRot(entity.getYRot());
               entityToSpawn.setYHeadRot(entity.getYRot());
               entityToSpawn.setDeltaMovement(0.0, 0.0, 0.0);
            }
         }
      }
   }
}
