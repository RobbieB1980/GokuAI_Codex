package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.LevelAccessor;

public class DEBUGTICKSEVENTProcedure {
   public static void execute(LevelAccessor world) {
      if (!world.isClientSide() && world.getServer() != null) {
         world.getServer()
            .getPlayerList()
            .broadcastSystemMessage(
               Component.literal("Ticks passés : " + ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer), false
            );
      }

      if (!world.isClientSide() && world.getServer() != null) {
         world.getServer()
            .getPlayerList()
            .broadcastSystemMessage(
               Component.literal("Ticks pour event : " + ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer_Time), false
            );
      }

      if (!world.isClientSide() && world.getServer() != null) {
         world.getServer()
            .getPlayerList()
            .broadcastSystemMessage(
               Component.literal("Niveau d'énervement d'Herobrine : " + ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger), false
            );
      }
   }
}
