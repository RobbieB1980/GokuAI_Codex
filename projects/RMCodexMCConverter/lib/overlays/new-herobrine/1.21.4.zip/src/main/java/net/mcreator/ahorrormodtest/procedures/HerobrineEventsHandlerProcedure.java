package net.mcreator.ahorrormodtest.procedures;

import org.jetbrains.annotations.Nullable;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Post;

@EventBusSubscriber
public class HerobrineEventsHandlerProcedure {
   @SubscribeEvent
   public static void onPlayerTick(Post event) {
      execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
   }

   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      execute(null, world, x, y, z, entity);
   }

   private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer = ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer
            + ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Speed;
         ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
         if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer
               >= ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer_Time
            && ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer_Time > 1.0) {
            ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type = Mth.nextInt(RandomSource.create(), 1, 11);
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            if (ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times > 2.0) {
               RandomActionEventsProcedure.execute(world, x, y, z, entity);
               ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
               ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
               ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times++;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes > 2.0
               && ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
               EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
               if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && world instanceof ServerLevel _level) {
                  LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                  entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
                  entityToSpawn.setVisualOnly(true);
                  _level.addFreshEntity(entityToSpawn);
               }

               ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
               ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
               ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            } else {
               if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times > 3.0) {
                  ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type = Mth.nextInt(RandomSource.create(), 1, 2);
                  ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 0.5 && Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
                     if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineAttackEnabled == 1.0) {
                        EVENTSHerobrineAttackNormalSpawnProcedure.execute(world, x, y, z, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     }
                  } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type == 1.0) {
                     if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
                        EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && world instanceof ServerLevel _level) {
                        LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                        entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
                        entityToSpawn.setVisualOnly(true);
                        _level.addFreshEntity(entityToSpawn);
                     }

                     ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 0.0;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes = 0.0;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare == 0.0
                     && ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type == 2.0) {
                     if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_JumpscaresEnabled == 1.0) {
                        EVENTSJumpscareHerobrineProcedure.execute(world, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 1.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
                        EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineBehindEnabled == 1.0) {
                        EVENTSHerobrineBehindNormalSpawnProcedure.execute(world, x, z, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && world instanceof ServerLevel _level) {
                        LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                        entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
                        entityToSpawn.setVisualOnly(true);
                        _level.addFreshEntity(entityToSpawn);
                     }
                  }

                  ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times++;
                  ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
               } else if ((!(ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 0.5) || Mth.nextInt(RandomSource.create(), 1, 2) != 2)
                  && Mth.nextInt(RandomSource.create(), 1, 4) != 3) {
                  if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type == 1.0) {
                     if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_JumpscaresEnabled == 1.0) {
                        EVENTSJumpscareHerobrineProcedure.execute(world, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 1.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
                        EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineBehindEnabled == 1.0) {
                        EVENTSHerobrineBehindNormalSpawnProcedure.execute(world, x, z, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && world instanceof ServerLevel _level) {
                        LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                        entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
                        entityToSpawn.setVisualOnly(true);
                        _level.addFreshEntity(entityToSpawn);
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                        _entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 1, false, false));
                     }

                     ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times++;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare == 0.0
                     && ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type == 2.0) {
                     if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_JumpscaresEnabled == 1.0) {
                        EVENTSJumpscareHerobrineProcedure.execute(world, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 1.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
                        EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes = 0.0;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineBehindEnabled == 1.0) {
                        EVENTSHerobrineBehindNormalSpawnProcedure.execute(world, x, z, entity);
                        ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
                        ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && world instanceof ServerLevel _level) {
                        LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                        entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
                        entityToSpawn.setVisualOnly(true);
                        _level.addFreshEntity(entityToSpawn);
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                        _entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 1, false, false));
                     }

                     ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times++;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type == 3.0) {
                     if (world instanceof Level _level) {
                        if (!_level.isClientSide()) {
                           _level.playSound(
                              null,
                              BlockPos.containing(x, y, z),
                              (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:surrounding_1")),
                              SoundSource.AMBIENT,
                              2.0F,
                              1.0F
                           );
                        } else {
                           _level.playLocalSound(
                              x,
                              y,
                              z,
                              (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:surrounding_1")),
                              SoundSource.AMBIENT,
                              2.0F,
                              1.0F,
                              false
                           );
                        }
                     }

                     if (world instanceof Level _level) {
                        if (!_level.isClientSide()) {
                           _level.playSound(
                              null,
                              BlockPos.containing(x, y, z),
                              (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.warden.heartbeat")),
                              SoundSource.AMBIENT,
                              2.0F,
                              1.0F
                           );
                        } else {
                           _level.playLocalSound(
                              x,
                              y,
                              z,
                              (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.warden.heartbeat")),
                              SoundSource.AMBIENT,
                              2.0F,
                              1.0F,
                              false
                           );
                        }
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
                        if (world instanceof ServerLevel _level) {
                           LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                           entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
                           entityToSpawn.setVisualOnly(true);
                           _level.addFreshEntity(entityToSpawn);
                        }

                        if (world instanceof ServerLevel _level) {
                           LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                           entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z + 5.0)));
                           entityToSpawn.setVisualOnly(true);
                           _level.addFreshEntity(entityToSpawn);
                        }

                        if (world instanceof ServerLevel _level) {
                           LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                           entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z - 5.0)));
                           entityToSpawn.setVisualOnly(true);
                           _level.addFreshEntity(entityToSpawn);
                        }
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                        _entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 1, false, false));
                     }

                     ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times++;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type == 4.0) {
                     if (world instanceof Level _level) {
                        if (!_level.isClientSide()) {
                           _level.playSound(
                              null,
                              BlockPos.containing(x, y, z),
                              (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:surrounding_3")),
                              SoundSource.AMBIENT,
                              2.0F,
                              1.0F
                           );
                        } else {
                           _level.playLocalSound(
                              x,
                              y,
                              z,
                              (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("thenewherobrinemod:surrounding_3")),
                              SoundSource.AMBIENT,
                              2.0F,
                              1.0F,
                              false
                           );
                        }
                     }

                     if (world instanceof Level _level) {
                        if (!_level.isClientSide()) {
                           _level.playSound(
                              null,
                              BlockPos.containing(x, y, z),
                              (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("block.glass.break")),
                              SoundSource.AMBIENT,
                              2.0F,
                              1.0F
                           );
                        } else {
                           _level.playLocalSound(
                              x,
                              y,
                              z,
                              (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("block.glass.break")),
                              SoundSource.AMBIENT,
                              2.0F,
                              1.0F,
                              false
                           );
                        }
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
                        if (world instanceof Level _level) {
                           if (!_level.isClientSide()) {
                              _level.playSound(
                                 null,
                                 BlockPos.containing(x, y, z),
                                 (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                                 SoundSource.AMBIENT,
                                 2.0F,
                                 1.0F
                              );
                           } else {
                              _level.playLocalSound(
                                 x,
                                 y,
                                 z,
                                 (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("ambient.cave")),
                                 SoundSource.AMBIENT,
                                 2.0F,
                                 1.0F,
                                 false
                              );
                           }
                        }

                        if (world instanceof ServerLevel _level) {
                           LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                           entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
                           entityToSpawn.setVisualOnly(true);
                           _level.addFreshEntity(entityToSpawn);
                        }

                        if (world instanceof ServerLevel _level) {
                           LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                           entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z + 5.0)));
                           entityToSpawn.setVisualOnly(true);
                           _level.addFreshEntity(entityToSpawn);
                        }

                        if (world instanceof ServerLevel _level) {
                           LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                           entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z - 5.0)));
                           entityToSpawn.setVisualOnly(true);
                           _level.addFreshEntity(entityToSpawn);
                        }
                     }

                     if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                        _entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 1, false, false));
                     }

                     ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times++;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type == 5.0) {
                     if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineBehindEnabled == 1.0) {
                        EVENTSHerobrineBehindNormalSpawnProcedure.execute(world, x, z, entity);
                     } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_FarHerobrineEnabled == 1.0) {
                        EVENTSFarHerobrineNormalSpawnProcedure.execute(world, x, y, z, entity);
                     } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_JumpscaresEnabled == 1.0) {
                        EVENTSJumpscareHerobrineProcedure.execute(world, entity);
                     }

                     ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times++;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Type >= 6.0) {
                     ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times++;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times = 0.0;
                     ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                     RandomActionEventsProcedure.execute(world, x, y, z, entity);
                  }
               } else {
                  if (ThenewherobrinemodModVariables.WorldVariables.get(world).CONFIG_HerobrineAttackEnabled == 1.0) {
                     EVENTSHerobrineAttackNormalSpawnProcedure.execute(world, x, y, z, entity);
                  }

                  ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Not_Spawned_Times = 0.0;
                  ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  ThenewherobrinemodModVariables.WorldVariables.get(world).WasJumpscare = 0.0;
                  ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && world instanceof ServerLevel _level) {
                     LightningBolt entityToSpawn = (LightningBolt)EntityTypes.LIGHTNING_BOLT.create(_level, EntitySpawnReason.TRIGGERED);
                     entityToSpawn.snapTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
                     entityToSpawn.setVisualOnly(true);
                     _level.addFreshEntity(entityToSpawn);
                  }

                  if (Mth.nextInt(RandomSource.create(), 1, 2) == 2 && entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
                     _entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 1, false, false));
                  }

                  ThenewherobrinemodModVariables.WorldVariables.get(world).Events_Not_Spawned_Times++;
                  ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
                  ThenewherobrinemodModVariables.WorldVariables.get(world).FarHerobrineNotSpawnedTimes++;
                  ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
               }

               ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer = 0.0;
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
               ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Spawn_Timer_Time = Mth.nextInt(
                  RandomSource.create(),
                  ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 0.4 ? 4450 : 5200,
                  ThenewherobrinemodModVariables.WorldVariables.get(world).Herobrine_Anger > 0.4 ? 6500 : 7000
               );
               ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            }
         }
      }
   }
}
