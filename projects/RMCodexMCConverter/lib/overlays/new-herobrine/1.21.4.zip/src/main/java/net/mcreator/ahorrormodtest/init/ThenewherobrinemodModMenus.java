package net.mcreator.ahorrormodtest.init;


import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import java.util.Map;
import net.mcreator.ahorrormodtest.network.MenuStateUpdateMessage;
import net.mcreator.ahorrormodtest.world.inventory.ConfigUIAdvancedMenu;
import net.mcreator.ahorrormodtest.world.inventory.ConfigUIHerobrineMenu;
import net.mcreator.ahorrormodtest.world.inventory.ConfigUIStructuresMenu;
import net.mcreator.ahorrormodtest.world.inventory.EnableShowHerobrineAngerWarningMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ThenewherobrinemodModMenus {
   public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, "thenewherobrinemod");
   public static final DeferredHolder<MenuType<?>, MenuType<ConfigUIHerobrineMenu>> CONFIG_UI_HEROBRINE = REGISTRY.register(
      "config_ui_herobrine", () -> IMenuTypeExtension.create(ConfigUIHerobrineMenu::new)
   );
   public static final DeferredHolder<MenuType<?>, MenuType<ConfigUIStructuresMenu>> CONFIG_UI_STRUCTURES = REGISTRY.register(
      "config_ui_structures", () -> IMenuTypeExtension.create(ConfigUIStructuresMenu::new)
   );
   public static final DeferredHolder<MenuType<?>, MenuType<ConfigUIAdvancedMenu>> CONFIG_UI_ADVANCED = REGISTRY.register(
      "config_ui_advanced", () -> IMenuTypeExtension.create(ConfigUIAdvancedMenu::new)
   );
   public static final DeferredHolder<MenuType<?>, MenuType<EnableShowHerobrineAngerWarningMenu>> ENABLE_SHOW_HEROBRINE_ANGER_WARNING = REGISTRY.register(
      "enable_show_herobrine_anger_warning", () -> IMenuTypeExtension.create(EnableShowHerobrineAngerWarningMenu::new)
   );

   public interface MenuAccessor {
      Map<String, Object> getMenuState();

      Map<Integer, Slot> getSlots();

      default void sendMenuStateUpdate(Player player, int elementType, String name, Object elementState, boolean needClientUpdate) {
         this.getMenuState().put(elementType + ":" + name, elementState);
         if (player instanceof ServerPlayer serverPlayer) {
            PacketDistributor.sendToPlayer(serverPlayer, new MenuStateUpdateMessage(elementType, name, elementState), new CustomPacketPayload[0]);
         } else if (player.level().isClientSide()) {
            if (Minecraft.getInstance().gui.screen() instanceof ThenewherobrinemodModScreens.ScreenAccessor accessor && needClientUpdate) {
               accessor.updateMenuState(elementType, name, elementState);
            }

            ClientPacketDistributor.sendToServer(new MenuStateUpdateMessage(elementType, name, elementState), new CustomPacketPayload[0]);
         }
      }

      default <T> T getMenuState(int elementType, String name, T defaultValue) {
         try {
            return (T)this.getMenuState().getOrDefault(elementType + ":" + name, defaultValue);
         } catch (ClassCastException e) {
            return defaultValue;
         }
      }
   }
}
