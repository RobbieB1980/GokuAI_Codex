package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.world.level.LevelAccessor;

public class HerobrineAngerShowProcedure {
   public static boolean execute(LevelAccessor world) {
      boolean ShowOrNot = false;
      if (ThenewherobrinemodModVariables.WorldVariables.get(world).HerobrineAngerDisplayConfirmed == 1.0) {
         ShowOrNot = true;
      } else {
         ShowOrNot = false;
      }

      return ShowOrNot;
   }
}
