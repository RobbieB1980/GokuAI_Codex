package net.mcreator.ahorrormodtest.procedures;

import net.mcreator.ahorrormodtest.ThenewherobrinemodMod;
import net.mcreator.ahorrormodtest.network.ThenewherobrinemodModVariables;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;

public class Far_Herobrine_Spawn_TasksProcedure {
   public static void execute(LevelAccessor world, Entity entity) {
      if (entity != null) {
         if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
            ThenewherobrinemodModVariables.WorldVariables.get(world).Far_Herobrine_Sword_Type = Mth.nextInt(RandomSource.create(), 1, 8);
            ThenewherobrinemodModVariables.WorldVariables.get(world).syncData(world);
            if (ThenewherobrinemodModVariables.WorldVariables.get(world).Far_Herobrine_Sword_Type == 1.0) {
               if (entity instanceof LivingEntity _entity) {
                  ItemStack _setstack = new ItemStack(Items.WOODEN_SWORD).copy();
                  _setstack.setCount(1);
                  _entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
                  if (_entity instanceof Player _player) {
                     _player.getInventory().setChanged();
                  }
               }
            } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Far_Herobrine_Sword_Type == 2.0) {
               if (entity instanceof LivingEntity _entity) {
                  ItemStack _setstack = new ItemStack(Items.STONE_SWORD).copy();
                  _setstack.setCount(1);
                  _entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
                  if (_entity instanceof Player _player) {
                     _player.getInventory().setChanged();
                  }
               }
            } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Far_Herobrine_Sword_Type == 3.0) {
               if (entity instanceof LivingEntity _entity) {
                  ItemStack _setstack = new ItemStack(Items.IRON_SWORD).copy();
                  _setstack.setCount(1);
                  _entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
                  if (_entity instanceof Player _player) {
                     _player.getInventory().setChanged();
                  }
               }
            } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Far_Herobrine_Sword_Type == 4.0) {
               if (entity instanceof LivingEntity _entity) {
                  ItemStack _setstack = new ItemStack(Items.GOLDEN_SWORD).copy();
                  _setstack.setCount(1);
                  _entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
                  if (_entity instanceof Player _player) {
                     _player.getInventory().setChanged();
                  }
               }
            } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Far_Herobrine_Sword_Type == 4.0) {
               if (entity instanceof LivingEntity _entity) {
                  ItemStack _setstack = new ItemStack(Items.DIAMOND_SWORD).copy();
                  _setstack.setCount(1);
                  _entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
                  if (_entity instanceof Player _player) {
                     _player.getInventory().setChanged();
                  }
               }
            } else if (ThenewherobrinemodModVariables.WorldVariables.get(world).Far_Herobrine_Sword_Type == 6.0) {
               if (entity instanceof LivingEntity _entity) {
                  ItemStack _setstack = new ItemStack(Items.NETHERITE_SWORD).copy();
                  _setstack.setCount(1);
                  _entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
                  if (_entity instanceof Player _player) {
                     _player.getInventory().setChanged();
                  }
               }
            } else if (entity instanceof LivingEntity _entity) {
               ItemStack _setstack = new ItemStack(Blocks.AIR).copy();
               _setstack.setCount(1);
               _entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
               if (_entity instanceof Player _player) {
                  _player.getInventory().setChanged();
               }
            }
         }

         ThenewherobrinemodMod.queueServerWork(100, () -> {
            if (!entity.level().isClientSide()) {
               entity.discard();
            }
         });
      }
   }
}
